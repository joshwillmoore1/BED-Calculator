/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firstscene;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author moore
 */
public class Popup_windowController implements Initializable {

    @FXML
    private Label LABEL3;

    @FXML
    private Label label1;

    @FXML
    private Label LABEL2;

    @FXML
    private Label label_new;

    @FXML
    private Label bed1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        label1.setText("D\u1D62\u2099\u1D62\u209C = Total dose used in initial treatment\n"
                + "\n"
                + "D\u1D63\u2091\u209C = Total dose used in re-treatment\n"
                + "\n"
                + "BED\u1D62\u2099\u1D62\u209C = The BED of the initial treatment\n"
                + "\n"
                + "BED\u1D63\u2091\u209C = The BED of the re-treatment\n"
                + "\n"
                + "BED\u1D63 = The BED that should result in risk of R%\n"
                + "\n"
                + "BED\u2081 = The ratio of BED\u1D62\u2099\u1D62\u209C to BED\u1D63 expressed a percentage\n"
                + "\n"
                + "BED\u2082 = The ratio of BED\u1D63\u2091\u209C to BED\u1D63 expressed as a percentage\n"
        );
        
        LABEL2.setText(" = Transition point between delayed and normal recovery");
        
        LABEL3.setText("s\u2080 = Transition steepness \n" + "\n"
                + "s\u2081 = Modulator scale for low BED\u2081 recovery\n");

        label_new.setText("LET = Linear energy transfer \n"
                + "\n"
                + "RBE = Relative biological effectiveness \n"
                + "\n"
                + "Constants set in the GUI for all \nproton treatment and retreatment: \n"
                + "\n"
                + "\u2022 s\u2080 = 0.15 \n"
                + "\n"
                + "\u2022 s\u2081 = 0.1 \n"
                + "\n"
                + "\u2022 Control megavoltage photon \n reference LET = 0.22 KeV/\u03bcm \n"
                + "\n"
        );
        
        bed1.setText("\u2022");

        
        
    }

}
