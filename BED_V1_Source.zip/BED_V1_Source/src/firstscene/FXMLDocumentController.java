/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firstscene;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.scene.control.Slider;
import java.text.DecimalFormat;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.stage.Stage;

public class FXMLDocumentController implements Initializable {

    @FXML
    private Text BEDret_text;

    @FXML
    private Text tissue_text_3;

    @FXML
    private Text tissue_text_2;

    @FXML
    private NumberAxis NumAxis14;

    @FXML
    private Text warn_bed_4;

    @FXML
    private Text warn_bed_3;

    @FXML
    private NumberAxis NumAxis12;

    @FXML
    private NumberAxis NumAxis13;

    @FXML
    private Text warn_bed_2;

    @FXML
    private Text Label_InitDose_3;

    @FXML
    private Text Label_InitDose_4;

    @FXML
    private TextField RiskOfMyel;

    @FXML
    private Text Label_InitDose_2;

    @FXML
    private NumberAxis NumAxis242;

    @FXML
    private Slider s0;

    @FXML
    private Slider s1;

    @FXML
    private TextField letx_3;

    @FXML
    private Button reset_4;

    @FXML
    private TextField letx_2;

    @FXML
    private TextField letx_4;

    @FXML
    private NumberAxis NumAxis22;

    @FXML
    private Button reset_2;

    @FXML
    private Button reset_3;

    @FXML
    private Text Label_initfrac;

    @FXML
    private NumberAxis NumAxis24;

    @FXML
    private Text BEDinit_text;

    @FXML
    private Label BED_label;

    @FXML
    private Text nom_text_3;

    @FXML
    private TextField DHIGH_4;

    @FXML
    private TextField DHIGH_2;

    @FXML
    private Label NumOfYearslabel;

    @FXML
    private TextField initalDose;

    @FXML
    private Button reset;

    @FXML
    private NumberAxis CatAxis242;

    @FXML
    private Button key_3;

    @FXML
    private Button key_2;

    @FXML
    private TextField RetreatFrac_3;

    @FXML
    private Button key_4;

    @FXML
    private NumberAxis NumAxis2;

    @FXML
    private Text letx_text_4;

    @FXML
    private NumberAxis NumAxis1;

    @FXML
    private Text letx_text_2;

    @FXML
    private Text letu_text_3;

    @FXML
    private Text letx_text_3;

    @FXML
    private Text letu_text_4;

    @FXML
    private Label out;

    @FXML
    private Text letu_text_2;

    @FXML
    private Text BEDret_text_2;

    @FXML
    private Text p_low;

    @FXML
    private Text tissue_text_21;

    @FXML
    private LineChart<?, ?> chart2_3;

    @FXML
    private TextField RetreatFrac;

    @FXML
    private LineChart<?, ?> chart2_4;

    @FXML
    private Label percentagelabel;

    @FXML
    private LineChart<?, ?> chart2_2;

    @FXML
    private Text eqn1_text;

    @FXML
    private Button key;

    @FXML
    private Slider BEDslider;

    @FXML
    private Text d_hi_4;

    @FXML
    private Slider PercentageSlider;

    @FXML
    private Text eqn3_text_4;

    @FXML
    private Text BEDR_text1;

    @FXML
    private Slider NumOfYearsSlider_3;

    @FXML
    private Slider NumOfYearsSlider_4;

    @FXML
    private Text BEDret_text_3;

    @FXML
    private Slider NumOfYearsSlider_2;

    @FXML
    private Text BEDret_text_4;

    @FXML
    private NumberAxis CatAxis2;

    @FXML
    private NumberAxis CatAxis1;

    @FXML
    private Slider NumOfYearsSlider;

    @FXML
    private Text eqn3_text_2;

    @FXML
    private Text eqn3_text_3;

    @FXML
    private Text d_hi_2;

    @FXML
    private Text initfrac_text;

    @FXML
    private Text p_low_2;

    @FXML
    private Text initfrac_text_4;

    @FXML
    private Text initfrac_text_3;

    @FXML
    private Text p_low_3;

    @FXML
    private Text initfrac_text_2;

    @FXML
    private Text p_low_4;

    @FXML
    private Text RBE_TEXT_3;

    @FXML
    private Text Label_InitDose;

    @FXML
    private TextField NumFrac_2;

    @FXML
    private ScatterChart<?, ?> chart1_4;

    @FXML
    private Text BED1_text;

    @FXML
    private ScatterChart<?, ?> chart1_2;

    @FXML
    private TextField NumFrac_4;

    @FXML
    private ScatterChart<?, ?> chart1_3;

    @FXML
    private TextField NumFrac_3;

    @FXML
    private TextField NumFrac;

    @FXML
    private Text p_high;

    @FXML
    private NumberAxis CatAxis13;

    @FXML
    private NumberAxis CatAxis12;

    @FXML
    private CheckBox RBE_CHECKBOX_4;

    @FXML
    private CheckBox RBE_CHECKBOX_3;

    @FXML
    private CheckBox RBE_CHECKBOX_2;

    @FXML
    private NumberAxis CatAxis14;

    @FXML
    private Label percentagelabel_3;

    @FXML
    private Text eqn2_text_4;

    @FXML
    private Text eqn2_text_3;

    @FXML
    private Label percentagelabel_4;

    @FXML
    private Label percentagelabel_2;

    @FXML
    private Text BED2_text_4;

    @FXML
    private Label NumOfYearslabel_3;

    @FXML
    private Label NumOfYearslabel_2;

    @FXML
    private Text ProDose_4;

    @FXML
    private Button Calculate;

    @FXML
    private Text BEDR_text_4;

    @FXML
    private Text ProDose_2;

    @FXML
    private Text eqn3_text;

    @FXML
    private NumberAxis CatAxis22;

    @FXML
    private Text BEDR_text_3;

    @FXML
    private Text BEDR_text_2;

    @FXML
    private TextField initalDose_2;

    @FXML
    private Label NumOfYearslabel_4;

    @FXML
    private Text BED2_text_3;

    @FXML
    private NumberAxis CatAxis24;

    @FXML
    private TextField initalDose_4;

    @FXML
    private Text BED2_text_2;

    @FXML
    private TextField initalDose_3;

    @FXML
    private Text eqn2_text_2;

    @FXML
    private LineChart<?, ?> chart2;

    @FXML
    private ScatterChart<?, ?> chart1;

    @FXML
    private Slider PercentageSlider_2;

    @FXML
    private Slider PercentageSlider_3;

    @FXML
    private Text nom_text;

    @FXML
    private Button Calculate_4;

    @FXML
    private Text s0_text;

    @FXML
    private Text eqn2_text;

    @FXML
    private Button Calculate_3;

    @FXML
    private Button Calculate_2;

    @FXML
    private Text BEDR2_TEXT_3;

    @FXML
    private Text BEDR2_TEXT_2;

    @FXML
    private TextField RiskOfMyel_4;

    @FXML
    private TextField RiskOfMyel_2;

    @FXML
    private Text BEDR2_TEXT;

    @FXML
    private TextField RiskOfMyel_3;

    @FXML
    private Label out_4;

    @FXML
    private Label out_3;

    @FXML
    private Label out_2;

    @FXML
    private Text s1_text;

    @FXML
    private Slider PercentageSlider_4;

    @FXML
    private Label s0_label;

    @FXML
    private Text eqn1_text_2;

    @FXML
    private Text BEDinit_text_2;

    @FXML
    private Text eqn1_text_3;

    @FXML
    private Text BEDinit_text_3;

    @FXML
    private Text Dret_text_4;

    @FXML
    private Text BED1_text_3;

    @FXML
    private Text eqn1_text_4;

    @FXML
    private Text warn_bed;

    @FXML
    private Text BED1_text_4;

    @FXML
    private Text Dret_text;

    @FXML
    private Text p_high_4;

    @FXML
    private Text Dret_text_3;

    @FXML
    private Text p_high_3;

    @FXML
    private Label s1_label;

    @FXML
    private Text Dret_text_2;

    @FXML
    private Text p_high_2;

    @FXML
    private Text Label_initfrac_3;

    @FXML
    private Text Label_initfrac_2;

    @FXML
    private Text tissue_text;

    @FXML
    private Text Label_initfrac_4;

    @FXML
    private Text BEDR2_TEXT_4;

    @FXML
    private Text BED2_text;

    @FXML
    private TextField letu_2;

    @FXML
    private Text BED1_text_2;

    @FXML
    private Text BEDinit_text_4;

    @FXML
    private TextField letu_4;

    @FXML
    private TextField letu_3;

    public FXMLDocumentController() {

    }

    public void initialize(URL url, ResourceBundle rb) {

        //DATA FOR STANDARD PLOTS - Rodent plots
        XYChart.Series series1 = new XYChart.Series();
        //series1.setName("Morrisxb");
        series1.getData().add(new XYChart.Data(22, 75));
        series1.getData().add(new XYChart.Data(40, 78));
        series1.getData().add(new XYChart.Data(80, 49));

        XYChart.Series series1_4 = new XYChart.Series();

        series1_4.getData().add(new XYChart.Data(22, 75));
        series1_4.getData().add(new XYChart.Data(40, 78));
        series1_4.getData().add(new XYChart.Data(80, 49));

        XYChart.Series series1_2 = new XYChart.Series();

        series1_2.getData().add(new XYChart.Data(22, 75));
        series1_2.getData().add(new XYChart.Data(40, 78));
        series1_2.getData().add(new XYChart.Data(80, 49));

        XYChart.Series series1_3 = new XYChart.Series();

        series1_3.getData().add(new XYChart.Data(22, 75));
        series1_3.getData().add(new XYChart.Data(40, 78));
        series1_3.getData().add(new XYChart.Data(80, 49));

        XYChart.Series series2 = new XYChart.Series();
        //series2.setName("Morrisbb");
        series2.getData().add(new XYChart.Data(82, 54));

        XYChart.Series series2_4 = new XYChart.Series();
        //series2.setName("Morrisbb");
        series2_4.getData().add(new XYChart.Data(82, 54));

        XYChart.Series series2_2 = new XYChart.Series();
        //series2.setName("Morrisbb");
        series2_2.getData().add(new XYChart.Data(82, 54));

        XYChart.Series series2_3 = new XYChart.Series();
        //series2.setName("Morrisbb");
        series2_3.getData().add(new XYChart.Data(82, 54));

        XYChart.Series series3 = new XYChart.Series();
        //series3.setName("Wong140");
        series3.getData().add(new XYChart.Data(47, 68.5));
        series3.getData().add(new XYChart.Data(71, 51.5));
        series3.getData().add(new XYChart.Data(89, 48.1));

        XYChart.Series series3_4 = new XYChart.Series();
        //series3.setName("Wong140");
        series3_4.getData().add(new XYChart.Data(47, 68.5));
        series3_4.getData().add(new XYChart.Data(71, 51.5));
        series3_4.getData().add(new XYChart.Data(89, 48.1));

        XYChart.Series series3_2 = new XYChart.Series();
        //series3.setName("Wong140");
        series3_2.getData().add(new XYChart.Data(47, 68.5));
        series3_2.getData().add(new XYChart.Data(71, 51.5));
        series3_2.getData().add(new XYChart.Data(89, 48.1));

        XYChart.Series series3_3 = new XYChart.Series();
        //series3.setName("Wong140");
        series3_3.getData().add(new XYChart.Data(47, 68.5));
        series3_3.getData().add(new XYChart.Data(71, 51.5));
        series3_3.getData().add(new XYChart.Data(89, 48.1));

        XYChart.Series series4 = new XYChart.Series();
        //series4.setName("Wong196");
        series4.getData().add(new XYChart.Data(47, 68.2));
        series4.getData().add(new XYChart.Data(71, 56.4));
        series4.getData().add(new XYChart.Data(89, 61.8));

        XYChart.Series series4_4 = new XYChart.Series();
        //series4.setName("Wong196");
        series4_4.getData().add(new XYChart.Data(47, 68.2));
        series4_4.getData().add(new XYChart.Data(71, 56.4));
        series4_4.getData().add(new XYChart.Data(89, 61.8));

        XYChart.Series series4_2 = new XYChart.Series();
        //series4.setName("Wong196");
        series4_2.getData().add(new XYChart.Data(47, 68.2));
        series4_2.getData().add(new XYChart.Data(71, 56.4));
        series4_2.getData().add(new XYChart.Data(89, 61.8));

        XYChart.Series series4_3 = new XYChart.Series();
        //series4.setName("Wong196");
        series4_3.getData().add(new XYChart.Data(47, 68.2));
        series4_3.getData().add(new XYChart.Data(71, 56.4));
        series4_3.getData().add(new XYChart.Data(89, 61.8));

        XYChart.Series series5 = new XYChart.Series();
        //series5.setName("Wong93");
        series5.getData().add(new XYChart.Data(25, 81));
        series5.getData().add(new XYChart.Data(50, 70));
        series5.getData().add(new XYChart.Data(75, 58));
        series5.getData().add(new XYChart.Data(90, 42));

        XYChart.Series series5_4 = new XYChart.Series();
        //series5.setName("Wong93");
        series5_4.getData().add(new XYChart.Data(25, 81));
        series5_4.getData().add(new XYChart.Data(50, 70));
        series5_4.getData().add(new XYChart.Data(75, 58));
        series5_4.getData().add(new XYChart.Data(90, 42));

        XYChart.Series series5_2 = new XYChart.Series();
        //series5.setName("Wong93");
        series5_2.getData().add(new XYChart.Data(25, 81));
        series5_2.getData().add(new XYChart.Data(50, 70));
        series5_2.getData().add(new XYChart.Data(75, 58));
        series5_2.getData().add(new XYChart.Data(90, 42));

        XYChart.Series series5_3 = new XYChart.Series();
        //series5.setName("Wong93");
        series5_3.getData().add(new XYChart.Data(25, 81));
        series5_3.getData().add(new XYChart.Data(50, 70));
        series5_3.getData().add(new XYChart.Data(75, 58));
        series5_3.getData().add(new XYChart.Data(90, 42));

        XYChart.Series series6 = new XYChart.Series();
        //series6.setName("Kogel1982");
        series6.getData().add(new XYChart.Data(67.7, 67.7));
        series6.getData().add(new XYChart.Data(66.5, 66.5));

        XYChart.Series series6_4 = new XYChart.Series();
        //series6.setName("Kogel1982");
        series6_4.getData().add(new XYChart.Data(67.7, 67.7));
        series6_4.getData().add(new XYChart.Data(66.5, 66.5));

        XYChart.Series series6_2 = new XYChart.Series();
        //series6.setName("Kogel1982");
        series6_2.getData().add(new XYChart.Data(67.7, 67.7));
        series6_2.getData().add(new XYChart.Data(66.5, 66.5));

        XYChart.Series series6_3 = new XYChart.Series();
        //series6.setName("Kogel1982");
        series6_3.getData().add(new XYChart.Data(67.7, 67.7));
        series6_3.getData().add(new XYChart.Data(66.5, 66.5));

        XYChart.Series series7 = new XYChart.Series();
        // series7.setName("Kolgel1991");
        series7.getData().add(new XYChart.Data(50, 90));
        series7.getData().add(new XYChart.Data(70, 71.1));
        series7.getData().add(new XYChart.Data(90, 35));

        XYChart.Series series7_4 = new XYChart.Series();
        // series7.setName("Kolgel1991");
        series7_4.getData().add(new XYChart.Data(50, 90));
        series7_4.getData().add(new XYChart.Data(70, 71.1));
        series7_4.getData().add(new XYChart.Data(90, 35));

        XYChart.Series series7_2 = new XYChart.Series();
        // series7.setName("Kolgel1991");
        series7_2.getData().add(new XYChart.Data(50, 90));
        series7_2.getData().add(new XYChart.Data(70, 71.1));
        series7_2.getData().add(new XYChart.Data(90, 35));

        XYChart.Series series7_3 = new XYChart.Series();
        // series7.setName("Kolgel1991");
        series7_3.getData().add(new XYChart.Data(50, 90));
        series7_3.getData().add(new XYChart.Data(70, 71.1));
        series7_3.getData().add(new XYChart.Data(90, 35));

        //line chart data
        XYChart.Series series8 = new XYChart.Series();
        series8.getData().add(new XYChart.Data(100, 0));
        series8.getData().add(new XYChart.Data(0, 100));

        XYChart.Series series8_4 = new XYChart.Series();
        series8_4.getData().add(new XYChart.Data(100, 0));
        series8_4.getData().add(new XYChart.Data(0, 100));

        XYChart.Series series8_2 = new XYChart.Series();
        series8_2.getData().add(new XYChart.Data(100, 0));
        series8_2.getData().add(new XYChart.Data(0, 100));

        XYChart.Series series8_3 = new XYChart.Series();
        series8_3.getData().add(new XYChart.Data(100, 0));
        series8_3.getData().add(new XYChart.Data(0, 100));

        XYChart.Series series9 = new XYChart.Series();
        XYChart.Series series10 = new XYChart.Series();
        XYChart.Series series11 = new XYChart.Series();
        XYChart.Series series12 = new XYChart.Series();
        XYChart.Series series13 = new XYChart.Series();
        XYChart.Series series14 = new XYChart.Series();
        XYChart.Series series15 = new XYChart.Series();

        XYChart.Series series9_2 = new XYChart.Series();
        XYChart.Series series10_2 = new XYChart.Series();
        XYChart.Series series11_2 = new XYChart.Series();
        XYChart.Series series12_2 = new XYChart.Series();
        XYChart.Series series13_2 = new XYChart.Series();
        XYChart.Series series14_2 = new XYChart.Series();
        XYChart.Series series15_2 = new XYChart.Series();

        XYChart.Series series9_4 = new XYChart.Series();
        XYChart.Series series10_4 = new XYChart.Series();
        XYChart.Series series11_4 = new XYChart.Series();
        XYChart.Series series12_4 = new XYChart.Series();
        XYChart.Series series13_4 = new XYChart.Series();
        XYChart.Series series14_4 = new XYChart.Series();
        XYChart.Series series15_4 = new XYChart.Series();

        XYChart.Series series9_3 = new XYChart.Series();
        XYChart.Series series10_3 = new XYChart.Series();
        XYChart.Series series11_3 = new XYChart.Series();
        XYChart.Series series12_3 = new XYChart.Series();
        XYChart.Series series13_3 = new XYChart.Series();
        XYChart.Series series14_3 = new XYChart.Series();
        XYChart.Series series15_3 = new XYChart.Series();

        // plot as a line graph and use css to manipluate the style of line
        chart1.getData().addAll(series1, series2, series3, series4, series5, series6, series7);
        chart2.getData().add(series8);

        chart1_4.getData().addAll(series1_4, series2_4, series3_4, series4_4, series5_4, series6_4, series7_4);
        chart2_4.getData().add(series8_4);

        chart1_2.getData().addAll(series1_2, series2_2, series3_2, series4_2, series5_2, series6_2, series7_2);
        chart2_2.getData().add(series8_2);

        chart1_3.getData().addAll(series1_3, series2_3, series3_3, series4_3, series5_3, series6_3, series7_3);
        chart2_3.getData().add(series8_3);

        //charts customisation - see css file for more 
        chart1.setLegendVisible(false);
        chart2.setLegendVisible(false);
        chart2.setAnimated(false);

        chart1_4.setLegendVisible(false);
        chart2_4.setLegendVisible(false);
        chart2_4.setAnimated(false);

        chart1_2.setLegendVisible(false);
        chart2_2.setLegendVisible(false);
        chart2_2.setAnimated(false);

        chart1_3.setLegendVisible(false);
        chart2_3.setLegendVisible(false);
        chart2_3.setAnimated(false);

        chart1.setHorizontalGridLinesVisible(false);
        chart1.setVerticalGridLinesVisible(false);

        chart1_4.setHorizontalGridLinesVisible(false);
        chart1_4.setVerticalGridLinesVisible(false);

        chart1_2.setHorizontalGridLinesVisible(false);
        chart1_2.setVerticalGridLinesVisible(false);

        chart1_3.setHorizontalGridLinesVisible(false);
        chart1_3.setVerticalGridLinesVisible(false);

        chart2.setHorizontalGridLinesVisible(false);
        chart2.setVerticalGridLinesVisible(false);
        chart2.setOpacity(1);
        chart2.setCreateSymbols(false);

        chart2_4.setHorizontalGridLinesVisible(false);
        chart2_4.setVerticalGridLinesVisible(false);
        chart2_4.setOpacity(1);
        chart2_4.setCreateSymbols(false);

        chart2_2.setHorizontalGridLinesVisible(false);
        chart2_2.setVerticalGridLinesVisible(false);
        chart2_2.setOpacity(1);
        chart2_2.setCreateSymbols(false);

        chart2_3.setHorizontalGridLinesVisible(false);
        chart2_3.setVerticalGridLinesVisible(false);
        chart2_3.setOpacity(1);
        chart2_3.setCreateSymbols(false);

        CatAxis2.setLabel("BED\u2081(%)");
        NumAxis2.setLabel("BED\u2082(%)");
        CatAxis1.setLabel("BED\u2081(%)");
        NumAxis1.setLabel("BED\u2082(%)");

        CatAxis24.setLabel("BED\u2081(%)");
        NumAxis24.setLabel("BED\u2082(%)");
        CatAxis14.setLabel("BED\u2081(%)");
        NumAxis14.setLabel("BED\u2082(%)");

        CatAxis22.setLabel("BED\u2081(%)");
        NumAxis22.setLabel("BED\u2082(%)");
        CatAxis12.setLabel("BED\u2081(%)");
        NumAxis12.setLabel("BED\u2082(%)");

        CatAxis242.setLabel("BED\u2081(%)");
        NumAxis242.setLabel("BED\u2082(%)");
        CatAxis13.setLabel("BED\u2081(%)");
        NumAxis13.setLabel("BED\u2082(%)");

        eqn1_text.setText("BED\u1D62\u2099\u1D62\u209C(Gy)   =   BED\u2081(%)   of   BED\u1D63(Gy)");
        eqn2_text.setText("BED\u1D63\u2091\u209C(Gy)   =   BED\u2082(%)   of   BED\u1D63(Gy)");
        eqn3_text.setText("Photon retreatment dose per fraction(Gy), D\u1D63\u2091\u209C/n(r) =");

        eqn1_text_2.setText("BED\u1D62\u2099\u1D62\u209C(Gy)   =   BED\u2081(%)   of   BED\u1D63(Gy)");
        eqn2_text_2.setText("BED\u1D63\u2091\u209C(Gy)   =   BED\u2082(%)   of   BED\u1D63(Gy)");
        eqn3_text_2.setText("Proton retreatment dose per fraction(Gy), D\u1D63\u2091\u209C/n(r) =");

        eqn1_text_3.setText("BED\u1D62\u2099\u1D62\u209C(Gy)   =   BED\u2081(%)   of   BED\u1D63(Gy)");
        eqn2_text_3.setText("BED\u1D63\u2091\u209C(Gy)   =   BED\u2082(%)   of   BED\u1D63(Gy)");
        eqn3_text_3.setText("Photon retreatment dose per fraction(Gy), D\u1D63\u2091\u209C/n(r) =");

        eqn1_text_4.setText("BED\u1D62\u2099\u1D62\u209C(Gy)   =   BED\u2081(%)   of   BED\u1D63(Gy)");
        eqn2_text_4.setText("BED\u1D63\u2091\u209C(Gy)   =   BED\u2082(%)   of   BED\u1D63(Gy)");
        eqn3_text_4.setText("Proton retreatment dose per fraction(Gy), D\u1D63\u2091\u209C/n(r) =");

        //USE UNICODE FOR THE SUBSCRIPTS FOR TAB1 TEXTS///////////////////////////
        Label_InitDose.setText("Photon initial total dose, D\u1D62\u2099\u1D62\u209C (Gy)");
        Label_initfrac.setText("Photon initial dose per fraction (Gy) \n d = D\u1D62\u2099\u1D62\u209C/ n");
        s0_text.setText("s\u2080");
        s1_text.setText("s\u2081");
        nom_text.setText("Nominal tolerated BED\u1D63 (Gy)");
        tissue_text.setText("Tissue sensitivity, \u03B1/\u03B2 (Gy)");
        out.setStyle("-fx-background-color:LIGHTGREY");

        /////////////UNICODE FOR TAB2 TEXT//////////////////////////////
        Label_InitDose_2.setText("Photon initial total dose, D\u1D62\u2099\u1D62\u209C (Gy)");
        Label_initfrac_2.setText("Photon initial dose per fraction (Gy) \n d = D\u1D62\u2099\u1D62\u209C/ n");
        tissue_text_2.setText("Tissue sensitivity, \u03B1/\u03B2 (Gy)");
        out_2.setStyle("-fx-background-color:LIGHTGREY");
        letu_text_2.setText("Maximum bio-efficiency, \n LET\u1D64 (KeV/\u03bcm)");
        letx_text_2.setText("Operative LET\u2093 (KeV/\u03bcm)");
        d_hi_2.setText("Proton physical retreatment \n dose d\u2095\u1D62 (Gy)");

        //TAB4//
        Label_InitDose_4.setText("Proton initial dose per fraction, d\u1D62\u2099\u1D62\u209C (Gy)");
        Label_initfrac_4.setText("Proton initial total dose D\u1D62\u2099\u1D62\u209C (Gy)");
        tissue_text_21.setText("Tissue sensitivity, \u03B1/\u03B2 (Gy)");
        out_4.setStyle("-fx-background-color:LIGHTGREY");
        letu_text_4.setText("Maximum bio-efficiency, \n LET\u1D64 (KeV/\u03bcm)");
        letx_text_4.setText("Operative LET\u2093 (KeV/\u03bcm)");
        d_hi_4.setText("Proton physical retreatment \n dose d\u2095\u1D62 (Gy)");

        //TAB3//
        Label_InitDose_3.setText("Proton initial dose per fraction, d\u1D62\u2099\u1D62\u209C (Gy)");
        Label_initfrac_3.setText("Proton initial total dose D\u1D62\u2099\u1D62\u209C (Gy)");
        nom_text_3.setText("Nominal tolerated BED\u1D63 (Gy)");
        tissue_text_3.setText("Tissue sensitivity, \u03B1/\u03B2 (Gy)");
        out_3.setStyle("-fx-background-color:LIGHTGREY");
        letu_text_3.setText("Maximum bio-efficiency, \n LET\u1D64 (KeV/\u03bcm)");
        letx_text_3.setText("Operative LET\u2093 (KeV/\u03bcm)");

        ////CODE FOR THE CHECKBOX FOR TAB 2//////////////////////////////////////////
        EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {

            public void handle(ActionEvent e) {
                if (RBE_CHECKBOX_2.isSelected()) {
                    letx_2.setDisable(true);
                    letx_text_2.setOpacity(0.3);
                    letx_2.setOpacity(0.3);
                    letu_2.setDisable(true);
                    letu_2.setOpacity(0.3);
                    letu_text_2.setOpacity(0.3);
                } else {
                    letx_2.setDisable(false);
                    letx_text_2.setOpacity(1);
                    letx_2.setOpacity(1);
                    letu_2.setDisable(false);
                    letu_2.setOpacity(1);
                    letu_text_2.setOpacity(1);
                }
            }

        };

        // set event to checkbox 
        RBE_CHECKBOX_2.setOnAction(event);

        EventHandler<ActionEvent> event4 = new EventHandler<ActionEvent>() {

            public void handle(ActionEvent e) {
                if (RBE_CHECKBOX_4.isSelected()) {
                    letx_4.setDisable(true);
                    letx_text_4.setOpacity(0.3);
                    letx_4.setOpacity(0.3);
                    letu_4.setDisable(true);
                    letu_4.setOpacity(0.3);
                    letu_text_4.setOpacity(0.3);
                } else {
                    letx_4.setDisable(false);
                    letx_text_4.setOpacity(1);
                    letx_4.setOpacity(1);
                    letu_4.setDisable(false);
                    letu_4.setOpacity(1);
                    letu_text_4.setOpacity(1);
                }
            }

        };

        // set event to checkbox 
        RBE_CHECKBOX_4.setOnAction(event4);

        EventHandler<ActionEvent> event3 = new EventHandler<ActionEvent>() {

            public void handle(ActionEvent e) {
                if (RBE_CHECKBOX_3.isSelected()) {
                    letx_3.setDisable(true);
                    letx_text_3.setOpacity(0.3);
                    letx_3.setOpacity(0.3);
                    letu_3.setDisable(true);
                    letu_3.setOpacity(0.3);
                    letu_text_3.setOpacity(0.3);
                } else {
                    letx_3.setDisable(false);
                    letx_text_3.setOpacity(1);
                    letx_3.setOpacity(1);
                    letu_3.setDisable(false);
                    letu_3.setOpacity(1);
                    letu_text_3.setOpacity(1);
                }
            }

        };

        // set event to checkbox 
        RBE_CHECKBOX_3.setOnAction(event3);

        //MAKE THE POPUP FOR NOTATION
        key.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                try {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Popup_window.fxml"));
                    Parent root1 = (Parent) fxmlLoader.load();

                    Stage stage = new Stage();
                    stage.setScene(new Scene(root1));
                    stage.setTitle("Information");
                    stage.setResizable(false);
                    stage.show();
                } catch (Exception e) {
                    System.out.println("Cannot display new window");
                }
            }
        });
        key_2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                try {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Popup_window.fxml"));
                    Parent root1 = (Parent) fxmlLoader.load();

                    Stage stage = new Stage();
                    stage.setScene(new Scene(root1));
                    stage.setTitle("Information");
                    stage.setResizable(false);
                    stage.show();
                } catch (Exception e) {
                    System.out.println("Cannot display new window");
                }
            }
        });
        key_4.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                try {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Popup_window.fxml"));
                    Parent root1 = (Parent) fxmlLoader.load();

                    Stage stage = new Stage();
                    stage.setScene(new Scene(root1));
                    stage.setTitle("Information");
                    stage.setResizable(false);
                    stage.show();
                } catch (Exception e) {
                    System.out.println("Cannot display new window");
                }
            }
        });
        key_3.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                try {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Popup_window.fxml"));
                    Parent root1 = (Parent) fxmlLoader.load();

                    Stage stage = new Stage();
                    stage.setScene(new Scene(root1));
                    stage.setTitle("Information");
                    stage.setResizable(false);
                    stage.show();
                } catch (Exception e) {
                    System.out.println("Cannot display new window");
                }
            }
        });
//initially the rodent data will not show on the plot
        chart1.setVisible(false);
        chart1_4.setVisible(false);
        chart1_2.setVisible(false);
        chart1_3.setVisible(false);

        //sort this out for the label, need to get it intially at 0.15 and only show to 2dp
        //LABELS FOR SLIDERS - TAB1//////////////////////////////////////
        s0.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                s0_label.textProperty().setValue(
                        String.valueOf((float) s0.getValue()));
            }
        });
        s1.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                s1_label.textProperty().setValue(
                        String.valueOf((float) s1.getValue()));
            }
        });
        BEDslider.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                BED_label.textProperty().setValue(
                        String.valueOf((int) BEDslider.getValue()));
            }
        });
        NumOfYearsSlider.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                NumOfYearslabel.textProperty().setValue(
                        String.valueOf((float) NumOfYearsSlider.getValue()));
            }
        });
        PercentageSlider.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                percentagelabel.textProperty().setValue(
                        String.valueOf((float) PercentageSlider.getValue()));
            }
        });

        /////////LABELS FOR SLIDERS - TAB4////////////////////////////////
        NumOfYearsSlider_4.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                NumOfYearslabel_4.textProperty().setValue(
                        String.valueOf((float) NumOfYearsSlider_4.getValue()));
            }
        });
        PercentageSlider_4.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                percentagelabel_4.textProperty().setValue(
                        String.valueOf((float) PercentageSlider_4.getValue()));
            }
        });
////////////////////////////////////LABELS FOR SLIDERS -TAB2 ///////////////////////////////////////////////////

        NumOfYearsSlider_2.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                NumOfYearslabel_2.textProperty().setValue(
                        String.valueOf((float) NumOfYearsSlider_2.getValue()));
            }
        });
        PercentageSlider_2.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                percentagelabel_2.textProperty().setValue(
                        String.valueOf((float) PercentageSlider_2.getValue()));
            }
        });

        ////////////////////////////////////LABELS FOR SLIDERS -TAB3 ///////////////////////////////////////////////////
        NumOfYearsSlider_3.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                NumOfYearslabel_3.textProperty().setValue(
                        String.valueOf((float) NumOfYearsSlider_3.getValue()));
            }
        });
        PercentageSlider_3.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object arg1, Object arg2) {
                percentagelabel_3.textProperty().setValue(
                        String.valueOf((float) PercentageSlider_3.getValue()));
            }
        });

//CALCULATION BUTTON//
        Calculate.setOnAction(new EventHandler<ActionEvent>() {

            //ROOT FINDER USING THE BISECTION METHOD
            public double probit0(double Dinit) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((Dinit) / D50_0) - 1))))));
            }

            public double Dret_0(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit0(a) * probit0(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit0(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit0(c) * probit0(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit1(double Dret1) {
                double gamma50_1 = (double) 9.5675;
                double D50_1 = (double) 64.3842;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((Dret1) / D50_1) - 1))))));  // Need the shift factor for conservative
            }

            public double Dret_1(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit1(a) * probit1(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit1(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit1(c) * probit1(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit2(double Dret2) {
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((Dret2) / D50_2) - 1))))));
            }

            public double Dret_2(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit2(a) * probit2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit2(c) * probit2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double probit3(double Dret3) {
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((Dret3) / D50_3) - 1))))));
            }

            public double Dret_3(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit3(a) * probit3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit3(c) * probit3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }
            //CALCULATING BEDS

            //////////////////Shifting for conservative factors for Human data/////////////////////////
            public double shifth0(double s) {
                double gamma50_0 = (double) 11.3764;
                double C = (double) PercentageSlider.getValue();
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + 54.8 * (1 - (C) * 0.01)) / D50_0) - 1))))));
            }

            public double shiftch(double a, double b) {
                double EPSILON = (double) 0.01;

                if (shifth0(a) * shifth0(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shifth0(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shifth0(c) * shifth0(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftm0(double s, double d) {
                double gamma50_0 = (double) 11.3764;
                double C = (double) PercentageSlider.getValue();
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + d * (1 - (C) * 0.01)) / D50_0) - 1))))));
            }

            public double shiftc(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_0(30, 70);
                //double D = BED_Rper(0);
                //double shift = shiftch(-1,20);

                if (shiftm0(a, d) * shiftm0(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftm0(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftm0(c, d) * shiftm0(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_1(double s, double d) {
                double gamma50_1 = (double) 9.5675;
                double C = (double) PercentageSlider.getValue();
                double D50_1 = (double) 64.3842;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((s + d * (1 - (C) * 0.01)) / D50_1) - 1))))));
            }

            public double shift1(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_1(30, 70);

                if (shiftD_1(a, d) * shiftD_1(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_1(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_1(c, d) * shiftD_1(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_2(double s, double d) {
                double C = (double) PercentageSlider.getValue();
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;
                //double D = Dret_2(30,200);

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((s + d * (1 - (C) * 0.01)) / D50_2) - 1))))));
            }

            public double shift2(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_2(30, 70);

                if (shiftD_2(a, d) * shiftD_2(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_2(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_2(c, d) * shiftD_2(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_3(double s, double d) {
                double C = (double) PercentageSlider.getValue();
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((s + d * (1 - (C) * 0.01)) / D50_3) - 1))))));  // Need the shift factor for conservative
            }

            public double shift3(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_3(30, 70);

                if (shiftD_3(a, d) * shiftD_3(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_3(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_3(c, d) * shiftD_3(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            ///////////////////////////////////////New Dret_0 ... Dret_3 with shift added to them//////////////
            public double probit0shift(double Dinit, double s) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                double P = 0.01 * Double.parseDouble(RiskOfMyel.getText());
                
                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + Dinit) / D50_0) - 1))))));
                // return (double) (p_eqn(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_0*(((s+Dinit)/D50_0)-1)))))); 
            }

            public double Dret_0shift(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shiftc((double) -0.1, 15);
                //  double shift = shiftch((double) -0.1,20);
                //  double d0 = BED_Rper(0);

                if (probit0shift(a, s) * probit0shift(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit0shift(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit0shift(c, s) * probit0shift(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit1shift(double Dret1, double s) {
                double gamma50_1 = (double) 9.5675;
                double D50_1 = (double) 64.3842;
                double P = 0.01 * Double.parseDouble(RiskOfMyel.getText());
                
                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((s + Dret1) / D50_1) - 1))))));
                // return (double) (p_eqn(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_1*(((s+Dret1)/D50_1)-1))))));  
            }

            public double Dret_1shift(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift1((double) -0.1, 15);
                //double shift = shiftch((double) -0.1,20);
                //double d0 = BED_Rper(0);

                if (probit1shift(a, s) * probit1shift(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit1shift(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit1shift(c, s) * probit1shift(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit2shift(double Dret1, double s) {
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;
                double P = 0.01 * Double.parseDouble(RiskOfMyel.getText());
                
                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((s + Dret1) / D50_2) - 1))))));
                // return (double) (p_eqn(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_2*(((s+Dret1)/D50_2)-1))))));  
            }

            public double Dret_2shift(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift2((double) -0.1, 15);
                // double shift = shiftch((double) -0.1,20);
                // double d0 = BED_Rper(0);

                if (probit2shift(a, s) * probit2shift(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit2shift(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit2shift(c, s) * probit2shift(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit3shift(double Dret1, double s) {
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;
                double P = 0.01 * Double.parseDouble(RiskOfMyel.getText());
                
                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((s + Dret1) / D50_3) - 1))))));
                //return (double) (p_eqn(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_3*(((s+Dret1)/D50_3)-1))))));  
            }

            public double Dret_3shift(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift3((double) -0.5, 15);
                //  double shift = shiftch((double) -0.1,20);
                //  double d0 = BED_Rper(0);

                if (probit3shift(a, s) * probit3shift(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit3shift(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit3shift(c, s) * probit3shift(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double HU_totaleq(double d, double s) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                double P = (double) (0.01 * Double.parseDouble(RiskOfMyel.getText()));
                
                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + d) / D50_0) - 1))))));
            }

            public double Dtol_Hu(double a, double b) {
                double EPSILON = (double) 0.001;
                double s = shiftch((double) -0.1, 20);

                if (HU_totaleq(a, s) * HU_totaleq(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (HU_totaleq(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (HU_totaleq(c, s) * HU_totaleq(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            ////////////////////////////////BED PERCENT CALCULATIONS/////////////////////////////////////////////  
            public double BED1_pc_human() {
                double INIT = Double.parseDouble(initalDose.getText());
                double FRAC = Double.parseDouble(NumFrac.getText());
                double k = INIT / FRAC;

                return (INIT * (1 + k / 2) / (Dtol_Hu(0, 120) * 2)) * 100;
            }

            public double BED1_pc() {
                return (44 / Dret_0shift(0, 120)) * 100;
            }

            public double BED21_pc() {
                return (Dret_1shift(30, 80) / Dret_0shift(0, 80)) * 100;
            }

            public double BED22_pc() {
                return (Dret_2shift(30, 80) / Dret_0shift(0, 80)) * 100;
            }

            public double BED23_pc() {
                return (Dret_3shift(30, 80) / Dret_0shift(30, 80)) * 100;
            }

            ///////////////// Risk p calculation///////////////////////////////////////////////////////////////////
            public double p_eqn(double d, double shiftch) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;

                return Double.parseDouble(RiskOfMyel.getText()) / 100;
                /* if (Double.parseDouble(RiskOfMyel.getText())==1){
            return (double) 0.01;}
        
        else if (Double.parseDouble(RiskOfMyel.getText())== 0.1){
        return (double) 0.0010001470751888064;}
    
        else 
        return (double) (0.5*(1+erf((double) (0.70710678118*(gamma50_0*((((Dtol_Hu(0,120))+shiftch)/D50_0)-1))))));    
                 */
                
            }

            ///////////////////////////////////////////////////////////////////////////////////  
            //BED OF PERCENTAGE R - NOMINAL VALUE
            public double BED_Rper(double a) {
                return Dtol_Hu(0, 120) * 2;
               
            }

            public double BED1(double a) {
                double INIT = Double.parseDouble(initalDose.getText());
                double FRAC = Double.parseDouble(NumFrac.getText());
                double k = INIT / FRAC;
                return ((INIT * (1 + k / 2)) / (BED_Rper(a))) * 100;

            }
            /////////////////////GETTING THE VALUES FOR r(1),r(2) and r(3)//////////////////////////////////////

            public double BED2_r1(double a) {
                double B = (double) BEDslider.getValue();
                double s_0 = (double) s0.getValue();
                double s_1 = (double) s1.getValue();
                double B1 = BED1_pc();

                return (double) (BED21_pc() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
                
            }

            public double r_1(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r1(a) * BED2_r1(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r1(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r1(c) * BED2_r1(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double BED2_r2(double a) {
                double B = (double) BEDslider.getValue();
                double s_0 = (double) s0.getValue();
                double s_1 = (double) s1.getValue();
                double B1 = BED1_pc();
                

                return (double) (BED22_pc() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
                 }

            public double r_2(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r2(a) * BED2_r2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r2(c) * BED2_r2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double BED2_r3(double a) {
                double B = (double) BEDslider.getValue();
                double s_0 = (double) s0.getValue();
                double s_1 = (double) s1.getValue();
                double B1 = BED1_pc();
              

                return (double) (BED23_pc() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
            }

            public double r_3(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r3(a) * BED2_r3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r3(c) * BED2_r3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }
//DEFINING THE r(t) FUNCTION - MAKE MORE EFFICIENT

            public double r(double t) {
                double Tiro = (double) 0.19;
                double m;
                double r_1 = r_1(0, 200);
                double r_2 = r_2(0, 200);
                double r_3 = r_3(0, 200);

                double a = 3 * (Tiro * r_1) / (Tiro - 1) - 3 * (Tiro * r_2) / (Tiro - 2) + (Tiro * r_3) / (Tiro - 3);
                double b = (double) (-0.5 * ((5 * Tiro + 6) * r_1) / (Tiro - 1) + (4 * Tiro + 3) * r_2 / (Tiro - 2) - 0.5 * (3 * Tiro + 2) * (r_3) / (Tiro - 3));
                double c = (double) (0.5 * (Tiro + 5) * (r_1) / (Tiro - 1) - (Tiro + 4) * (r_2) / (Tiro - 2) + 0.5 * (Tiro + 3) * (r_3) / (Tiro - 3));
                double d = (double) (-0.5 * (r_1) / (Tiro - 1) + (r_2) / (Tiro - 2) - 0.5 * (r_3) / (Tiro - 3));
                if (t < Tiro) {
                    return 0;
                } else {
                    return m = (double) (a + b * t + c * Math.pow(t, 2) + d * Math.pow(t, 3));
                }

            }
            //////////// BED2 for the graph ////////////////////////////////////////

            public double BED2_FINAL(double a) {
                double B = (double) BEDslider.getValue();
                double s_0 = (double) s0.getValue();
                double s_1 = (double) s1.getValue();
                double t = (double) NumOfYearsSlider.getValue();

                if (a < 100) {
                    return (double) (100 * (1 - a * 0.01) * (1 + (Math.pow(1 - a * 0.01, -r(t) / (r(t) + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (a - B / (1 + s_1 * r(t)))))));
                } else {
                    return 0;
                }
            }
            ////////////////////////BED2 FOR TEXT LABEL//////////////////////////////////////////////

            public double BED2(double a) {
                double B = (double) BEDslider.getValue();
                double s_0 = (double) s0.getValue();
                double s_1 = (double) s1.getValue();
                double t = (double) NumOfYearsSlider.getValue();
                double B1 = BED1(0);

                return (double) (100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -r(t) / (r(t) + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * r(t)))))));

            }
            //////// Function to find the Dret/n(r) ////////////////////////////

            public double dosefcn(double d) {
                double n = Double.parseDouble(RetreatFrac.getText());
                return (double) (BED2(500) * BED_Rper(500) * 0.01 - (n * d + n * d * d / 2));

            }

            public double dose(double a, double b) {
                double EPSILON = (double) 0.001;

                if (dosefcn(a) * dosefcn(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (dosefcn(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (dosefcn(c) * dosefcn(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }
//create new series for each button pressed 

            @Override
            public void handle(ActionEvent event) {

                long startTime = System.nanoTime();

                series9.getData().clear();
                series10.getData().clear();
                series11.getData().clear();
                series12.getData().clear();
                series13.getData().clear();
                series14.getData().clear();
                series15.getData().clear();

                warn_bed.setVisible(false);
                p_high.setVisible(false);
                p_low.setVisible(false);
                out.setVisible(true);
                BED1_text.setVisible(true);
                BEDinit_text.setVisible(true);
                BEDR_text1.setVisible(true);
                BEDR2_TEXT.setVisible(true);
                BED2_text.setVisible(true);
                BEDret_text.setVisible(true);
                Dret_text.setVisible(true);

                DecimalFormat df2 = new DecimalFormat("#.##");
                double D = BED_Rper(0);
                double S = shiftch(-1, 20);

                ///////////////////WARNINGS//////////////////////////////////////////////     
                if (BED1_pc_human() > 100) {
                    warn_bed.setVisible(true);
                    warn_bed.setText("WARNING: INITIAL DOSE OVER TOLERANCE");
                    p_high.setVisible(false);
                    p_low.setVisible(false);
                    BED1_text.setText("NA");
                    BEDinit_text.setText("NA");
                    BEDR_text1.setText("NA");
                    BEDR2_TEXT.setText("NA");
                    BED2_text.setText("NA");
                    BEDret_text.setText("NA");
                    Dret_text.setText("NA");
                    out.setText("NA");
                } else if (p_eqn(D, S) > 0.999) {
                    p_high.setVisible(true);
                    p_high.setText("WARNING: RISK GREATER THAN 99.9%");
                    BED1_text.setText("NA");
                    BEDinit_text.setText("NA");
                    BEDR_text1.setText("NA");
                    BEDR2_TEXT.setText("NA");
                    BED2_text.setText("NA");
                    BEDret_text.setText("NA");
                    Dret_text.setText("NA");
                    out.setText("NA");
                    warn_bed.setVisible(false);
                    p_low.setVisible(false);
                } else if (p_eqn(D, S) < 1e-5) {
                    p_low.setVisible(true);
                    p_low.setText("WARNING: RISK LESS THAN 0.001%");
                    BED1_text.setText("NA");
                    BEDinit_text.setText("NA");
                    BEDR_text1.setText("NA");
                    BEDR2_TEXT.setText("NA");
                    BED2_text.setText("NA");
                    BEDret_text.setText("NA");
                    Dret_text.setText("NA");
                    out.setText("NA");
                    warn_bed.setVisible(false);
                    p_high.setVisible(false);
                } else {

                    double INIT = Double.parseDouble(initalDose.getText());
                    double FRAC = Double.parseDouble(NumFrac.getText());
                    double k = INIT / FRAC;
                    initfrac_text.setText(df2.format(k));

//CODE FOR THE LABELS BEDS
                    BED1_text.setText(df2.format(BED1(500)));
                    BEDinit_text.setText(df2.format((INIT * (1 + k / 2))));
                    BEDR_text1.setText(df2.format((BED_Rper(500))));
                    BEDR2_TEXT.setText(df2.format(BED_Rper(500)));
                    BED2_text.setText(df2.format(BED2(500)));
                    BEDret_text.setText(df2.format((BED2(500) * (BED_Rper(500))) / 100));
                    Dret_text.setText(df2.format(dose(0, 5)));
                    out.setText(df2.format(BED_Rper(500)));

                    warn_bed.setVisible(false);
                    p_high.setVisible(false);
                    p_low.setVisible(false);
                    out.setVisible(true);
                    BED1_text.setVisible(true);
                    BEDinit_text.setVisible(true);
                    BEDR_text1.setVisible(true);
                    BEDR2_TEXT.setVisible(true);
                    BED2_text.setVisible(true);
                    BEDret_text.setVisible(true);
                    Dret_text.setVisible(true);

                }

// VERFICATION OF THE TEXTFIELD DATA
                try {
                    double RiskVal = Double.parseDouble(RiskOfMyel.getText());
                    if (RiskVal > 0 && RiskVal < 100) {
                        RiskVal = RiskVal;
                    } else {
                        RiskVal = 1;
                        RiskOfMyel.setText("1");
                    }
                    System.out.println("Risk Of Myel is " + RiskVal);
                } catch (NumberFormatException RiskVal) {
                    System.out.println("Error:" + " is not valid");
                    RiskOfMyel.setText("1");
                }

                try {
                    double InitalVal = Double.parseDouble(initalDose.getText());
                    if (InitalVal > 0) {
                        InitalVal = InitalVal;
                    } else {
                        InitalVal = 40;
                        initalDose.setText("40");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    initalDose.setText("40");
                }

                try {
                    int NumVal = Integer.parseInt(NumFrac.getText());
                    if (NumVal > 0) {
                        NumVal = NumVal;
                    } else {
                        NumVal = 20;
                        NumFrac.setText("20");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    NumFrac.setText("20");
                }

                try {
                    int RetVal = Integer.parseInt(RetreatFrac.getText());
                    if (RetVal > 0) {
                        RetVal = RetVal;
                    } else {
                        RetVal = 20;
                        RetreatFrac.setText("20");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    RetreatFrac.setText("20");

                }

//PUT VALUES OF BED2 INTO AN ARRAY
                double BED2Array[] = new double[101];
                for (int j = 0; j < 101; j++) {

                    double value1 = BED2_FINAL(j);
                    BED2Array[j] = value1;
                }

                //NEED TO MAKE A NEW SERIES EACH TIME THE FUNCTION IS CALLED!!! MAKE A IF STATEMENT FOR THIS        
                for (int i = 0; i < 101; i++) {
                    series9.getData().add(new XYChart.Data(i, BED2Array[i]));
                }
                series10.getData().add(new XYChart.Data(BED1_pc(), BED21_pc()));
                series11.getData().add(new XYChart.Data(BED1_pc(), BED22_pc()));

                series12.getData().add(new XYChart.Data(BED1_pc(), BED23_pc()));

                series13.getData().add(new XYChart.Data(BED1_pc_human(), BED2_FINAL(BED1_pc_human())));
                series14.getData().add(new XYChart.Data(0, BED2_FINAL(BED1_pc_human())));
                series14.getData().add(new XYChart.Data(BED1_pc_human(), BED2_FINAL(BED1_pc_human())));

                series15.getData().add(new XYChart.Data(BED1_pc_human(), 0));
                series15.getData().add(new XYChart.Data(BED1_pc_human(), BED2_FINAL(BED1_pc_human())));

                chart2.getData().addAll(series9, series10, series11, series12, series13, series14, series15);

                long endTime = System.nanoTime();
                long totalTime = endTime - startTime;
                System.out.println("Total time for calculation " + totalTime / 1e9 + " seconds");

            }

        });
        ////////////////////////////// CALCULATION BUTTON FOR TAB 4 ///////////////////////////////////////////////  

        Calculate_4.setOnAction(new EventHandler<ActionEvent>() {

            public double alpha_u_4_IN() {
                return (10.57 / 3.92) * (1 - Math.exp(-3.92 * alpha_low));
            }

            public double Ahi_4_IN() {
                double letx = Double.parseDouble(letx_4.getText());
                double letu = Double.parseDouble(letu_4.getText());

                return alpha_low + (alpha_u_4_IN() - alpha_low) * (letx - 0.22) / (letu - 0.22);
            }

            public double beta_u_4_IN() {
                return 0.06 * (1 - Math.exp(-50 * beta_low));
            }

            public double Bhi_4_IN() {
                double letx = Double.parseDouble(letx_4.getText());
                double letu = Double.parseDouble(letu_4.getText());

                return beta_low + (beta_u_4_IN() - beta_low) * (letx - 0.22) / (letu - 0.22);

            }

            public double d_low_2_4_IN() {
                double d_hi = Double.parseDouble(initalDose_4.getText());

                return 1 / (2 * beta_low) * (-alpha_low + Math.pow(alpha_low * alpha_low + 4 * Ahi_4_IN() * beta_low * d_hi + 4 * Bhi_4_IN() * beta_low * d_hi * d_hi, 0.5));

            }

            public double RBE_4_IN() {
                double d_hi = Double.parseDouble(initalDose_4.getText());
                DecimalFormat df2 = new DecimalFormat("#.##");
                double m;
                if (RBE_CHECKBOX_4.isSelected()) {
                    return 1.1;
                } else {
                    m = (d_low_2_4_IN() / d_hi);
                }
                return Math.round(m * 100d) / 100d;

            }

            public double alpha_u_4_RE() {
                return (10.57 / 3.92) * (1 - Math.exp(-3.92 * alpha_low));
            }

            public double Ahi_4_RE() {
                double letx = Double.parseDouble(letx_4.getText());
                double letu = Double.parseDouble(letu_4.getText());

                return alpha_low + (alpha_u_4_RE() - alpha_low) * (letx - 0.22) / (letu - 0.22);
            }

            public double beta_u_4_RE() {
                return 0.06 * (1 - Math.exp(-50 * beta_low));
            }

            public double Bhi_4_RE() {
                double letx = Double.parseDouble(letx_4.getText());
                double letu = Double.parseDouble(letu_4.getText());

                return beta_low + (beta_u_4_RE() - beta_low) * (letx - 0.22) / (letu - 0.22);

            }

            public double d_low_2_4_RE() {
                double d_hi = Double.parseDouble(DHIGH_4.getText());

                return 1 / (2 * beta_low) * (-alpha_low + Math.pow(alpha_low * alpha_low + 4 * Ahi_4_RE() * beta_low * d_hi + 4 * Bhi_4_RE() * beta_low * d_hi * d_hi, 0.5));

            }

            public double RBE_4_RE() {
                double d_hi = Double.parseDouble(DHIGH_4.getText());
                if (RBE_CHECKBOX_4.isSelected()) {
                    return 1.1;
                } else {
                    return d_low_2_4_RE() / d_hi;
                }

            }
////////////////////////// TAB2 EQNS SAME AS PHOTON /////////////////////////////

            public double probit0_4(double Dinit) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((Dinit) / D50_0) - 1))))));
            }

            public double Dret_0_4(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit0_4(a) * probit0_4(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit0_4(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit0_4(c) * probit0_4(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit1_4(double Dret1) {
                double gamma50_1 = (double) 9.5675;
                double D50_1 = (double) 64.3842;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((Dret1) / D50_1) - 1)))))); 
            }

            public double Dret_1_4(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit1_4(a) * probit1_4(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit1_4(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit1_4(c) * probit1_4(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit2_4(double Dret2) {
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((Dret2) / D50_2) - 1))))));
            }

            public double Dret_2_4(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit2_4(a) * probit2_4(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit2_4(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit2_4(c) * probit2_4(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double probit3_4(double Dret3) {
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((Dret3) / D50_3) - 1))))));
            }

            public double Dret_3_4(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit3_4(a) * probit3_4(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit3_4(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit3_4(c) * probit3_4(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }
            //CALCULATING BEDS

            //////////////////Shifting for conservative factors for Human data/////////////////////////
            public double shifth0_4(double s) {
                double gamma50_0 = (double) 11.3764;
                double C = (double) PercentageSlider_4.getValue();
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + 54.8 * (1 - (C) * 0.01)) / D50_0) - 1)))))); 
            }

            public double shiftch_4(double a, double b) {
                double EPSILON = (double) 0.01;

                if (shifth0_4(a) * shifth0_4(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shifth0_4(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shifth0_4(c) * shifth0_4(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftm0_4(double s, double d) {
                double gamma50_0 = (double) 11.3764;
                double C = (double) PercentageSlider_4.getValue();
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + d * (1 - (C) * 0.01)) / D50_0) - 1))))));  
            }

            public double shiftc_4(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_0_4(30, 70);
                //double D = BED_Rper(0);
                //double shift = shiftch(-1,20);

                if (shiftm0_4(a, d) * shiftm0_4(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftm0_4(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftm0_4(c, d) * shiftm0_4(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_1_4(double s, double d) {
                double gamma50_1 = (double) 9.5675;
                double C = (double) PercentageSlider_4.getValue();
                double D50_1 = (double) 64.3842;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((s + d * (1 - (C) * 0.01)) / D50_1) - 1))))));
            }

            public double shift1_4(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_1_4(30, 70);

                if (shiftD_1_4(a, d) * shiftD_1_4(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_1_4(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_1_4(c, d) * shiftD_1_4(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_2_4(double s, double d) {
                double C = (double) PercentageSlider_4.getValue();
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((s + d * (1 - (C) * 0.01)) / D50_2) - 1))))));
            }

            public double shift2_4(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_2_4(30, 70);

                if (shiftD_2_4(a, d) * shiftD_2_4(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_2_4(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_2_4(c, d) * shiftD_2_4(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_3_4(double s, double d) {
                double C = (double) PercentageSlider_4.getValue();
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((s + d * (1 - (C) * 0.01)) / D50_3) - 1))))));  
            }

            public double shift3_4(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_3_4(30, 70);

                if (shiftD_3_4(a, d) * shiftD_3_4(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_3_4(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_3_4(c, d) * shiftD_3_4(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            ///////////////////////////////////////New Dret_0 ....Dret_3 with shift added to them//////////////
            public double probit0shift_4(double Dinit, double s) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_4.getText());

                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + Dinit) / D50_0) - 1))))));

                // return (double) (p_eqn_4(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_0*(((s+Dinit)/D50_0)-1))))));
            }

            public double Dret_0shift_4(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shiftc_4((double) -0.1, 15);
                // double shift = shiftch_4((double) -0.1,20);
                // double d0 = BED_Rper_4(0);

                if (probit0shift_4(a, s) * probit0shift_4(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit0shift_4(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit0shift_4(c, s) * probit0shift_4(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit1shift_4(double Dret1, double s) {
                double gamma50_1 = (double) 9.5675;
                double D50_1 = (double) 64.3842;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_4.getText());

                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((s + Dret1) / D50_1) - 1))))));
                //  return (double) (p_eqn_4(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_1*(((s+Dret1)/D50_1)-1)))))); 
            }

            public double Dret_1shift_4(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift1_4((double) -0.1, 15);
                // double shift = shiftch_4((double) -0.1,20);
                // double d0 = BED_Rper_4(0);

                if (probit1shift_4(a, s) * probit1shift_4(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit1shift_4(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit1shift_4(c, s) * probit1shift_4(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit2shift_4(double Dret1, double s) {
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_4.getText());

                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((s + Dret1) / D50_2) - 1))))));
                //return (double) (p_eqn_4(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_2*(((s+Dret1)/D50_2)-1)))))); 
            }

            public double Dret_2shift_4(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift2_4((double) -0.1, 15);
                //  double shift = shiftch_4((double) -0.1,20);
                // double d0 = BED_Rper_4(0);

                if (probit2shift_4(a, s) * probit2shift_4(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit2shift_4(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit2shift_4(c, s) * probit2shift_4(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit3shift_4(double Dret1, double s) {
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_4.getText());

                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((s + Dret1) / D50_3) - 1))))));
                //  return (double) (p_eqn_4(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_3*(((s+Dret1)/D50_3)-1)))))); 
            }

            public double Dret_3shift_4(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift3_4((double) -0.5, 15);
                //  double shift = shiftch_4((double) -0.1,20);
                // double d0 = BED_Rper_4(0);

                if (probit3shift_4(a, s) * probit3shift_4(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit3shift_4(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit3shift_4(c, s) * probit3shift_4(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double HU_totaleq_4(double d, double s) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                double P = (double) (0.01 * Double.parseDouble(RiskOfMyel_4.getText()));
                
                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + d) / D50_0) - 1))))));
            }

            public double Dtol_Hu_4(double a, double b) {
                double EPSILON = (double) 0.001;
                double s = shiftch_4((double) -0.1, 20);

                if (HU_totaleq_4(a, s) * HU_totaleq_4(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (HU_totaleq_4(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (HU_totaleq_4(c, s) * HU_totaleq_4(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            ///////////////////////////////////Percentage BED calculations - paper //////////////////////////////////////////  
            public double BED1_pc_human_4() {
                double INIT = Double.parseDouble(initalDose_4.getText());
                double FRAC = Double.parseDouble(NumFrac_4.getText());
                double k = (RBE_4_IN() * INIT);

                return (k * FRAC * (1 + k / 2) / (Dtol_Hu_4(0, 120) * 2)) * 100;
            }

            public double BED1_pc_4() {
                return (44 / Dret_0shift_4(0, 120)) * 100;
                
            }

            public double BED21_pc_4() {
                return (Dret_1shift_4(30, 80) / Dret_0shift_4(0, 80)) * 100;
            }

            public double BED22_pc_4() {
                return (Dret_2shift_4(30, 80) / Dret_0shift_4(0, 80)) * 100;
            }

            public double BED23_pc_4() {
                return (Dret_3shift_4(30, 80) / Dret_0shift_4(30, 80)) * 100;
            }

            ///////////////// P_CALC FROM MATLAB ///////////////////////////////////////////////////////////////////
            public double p_eqn_4(double d, double shiftch) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                return Double.parseDouble(RiskOfMyel_4.getText()) / 100;
                /*
         if (Double.parseDouble(RiskOfMyel_4.getText())==1){
            return (double) 0.01;}
        
        else if (Double.parseDouble(RiskOfMyel_4.getText())== 0.1){
        return (double) 0.0010001470751888064;}
    
        else 
        return (double) (0.5*(1+erf((double) (0.70710678118*(gamma50_0*((((Dtol_Hu_4(0,120))+shiftch)/D50_0)-1))))));    
                 */
                
            }

            ///////////////////////////////////////////////////////////////////////////////////  
            //BED OF PERCENTAGE R - NOMINAL VALUE
            public double BED_Rper_4(double a) {
                return Dtol_Hu_4(0, 120) * 2;
               
            }
      
            public double BED1_4(double a) {
                double INIT = Double.parseDouble(initalDose_4.getText());
                double FRAC = Double.parseDouble(NumFrac_4.getText());
                double k = RBE_4_IN() * INIT;

                return ((k * FRAC * (1 + (k) / 2)) / (BED_Rper_4(a))) * 100;

            }
            /////////////////////GETTING THE VALUES FOR r(1),r(2) and r(3)//////////////////////////////////////

            public double BED2_r1_4(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double B1 = BED1_pc_4();

                return (double) (BED21_pc_4() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
               
            }

            public double r_1_4(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r1_4(a) * BED2_r1_4(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r1_4(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r1_4(c) * BED2_r1_4(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double BED2_r2_4(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double B1 = BED1_pc_4();
                
                return (double) (BED22_pc_4() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
                
            }

            public double r_2_4(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r2_4(a) * BED2_r2_4(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r2_4(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r2_4(c) * BED2_r2_4(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double BED2_r3_4(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double B1 = BED1_pc_4();
                
                return (double) (BED23_pc_4() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
                
            }

            public double r_3_4(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r3_4(a) * BED2_r3_4(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r3_4(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r3_4(c) * BED2_r3_4(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }
//DEFINING THE r(t) FUNCTION - MAKE MORE EFFICIENT

            public double r_4(double t) {
                double Tiro = (double) 0.19;
                double m;
                double r_1 = r_1_4(0, 200);
                double r_2 = r_2_4(0, 200);
                double r_3 = r_3_4(0, 200);

                double a = 3 * (Tiro * r_1) / (Tiro - 1) - 3 * (Tiro * r_2) / (Tiro - 2) + (Tiro * r_3) / (Tiro - 3);
                double b = (double) (-0.5 * ((5 * Tiro + 6) * r_1) / (Tiro - 1) + (4 * Tiro + 3) * r_2 / (Tiro - 2) - 0.5 * (3 * Tiro + 2) * (r_3) / (Tiro - 3));
                double c = (double) (0.5 * (Tiro + 5) * (r_1) / (Tiro - 1) - (Tiro + 4) * (r_2) / (Tiro - 2) + 0.5 * (Tiro + 3) * (r_3) / (Tiro - 3));
                double d = (double) (-0.5 * (r_1) / (Tiro - 1) + (r_2) / (Tiro - 2) - 0.5 * (r_3) / (Tiro - 3));
                if (t < Tiro) {
                    return 0;
                } else {
                    return m = (double) (a + b * t + c * Math.pow(t, 2) + d * Math.pow(t, 3));
                }

            }
            //////////// BED2 for the graph ////////////////////////////////////////

            public double BED2_FINAL_4(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double t = (double) NumOfYearsSlider_4.getValue();

                if (a < 100) {
                    return (double) (100 * (1 - a * 0.01) * (1 + (Math.pow(1 - a * 0.01, -r_4(t) / (r_4(t) + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (a - B / (1 + s_1 * r_4(t)))))));
                } else {
                    return 0;
                }
            }
            ////////////////////////BED2 FOR TEXT LABEL//////////////////////////////////////////////

            public double BED2__4(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double t = (double) NumOfYearsSlider_4.getValue();

                double B1 = BED1_4(0);

                return (double) (100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -r_4(t) / (r_4(t) + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * r_4(t)))))));

            }
            //////// Function to find the n(r) ////////////////////////////

            public double dosefcn_4(double n) {
                double D = Double.parseDouble(DHIGH_4.getText());
                if (RBE_CHECKBOX_4.isSelected()) {
                    double d = D * RBE_4_RE();
                    return (double) (BED2__4(500) * BED_Rper_4(500) * 0.01 - (n * d + n * d * d / 2));

                } else {
                    double d = D * RBE_4_RE();
                    return (double) (BED2__4(500) * BED_Rper_4(500) * 0.01 - (n * d + n * d * d / 2));
                }

            }

            public double dose_4(double a, double b) {
                double EPSILON = (double) 0.001;

                if (dosefcn_4(a) * dosefcn_4(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (dosefcn_4(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (dosefcn_4(c) * dosefcn_4(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }

                return Math.floor(c);

            }

            @Override
            public void handle(ActionEvent event) {
                long startTime = System.nanoTime();

                series9_4.getData().clear();
                series10_4.getData().clear();
                series11_4.getData().clear();
                series12_4.getData().clear();
                series13_4.getData().clear();
                series14_4.getData().clear();
                series15_4.getData().clear();

                warn_bed_4.setVisible(false);
                p_high_4.setVisible(false);
                p_low_4.setVisible(false);
                out_4.setVisible(true);
                BED1_text_4.setVisible(true);
                BEDinit_text_4.setVisible(true);
                BEDR_text_4.setVisible(true);
                BEDR2_TEXT_4.setVisible(true);
                BED2_text_4.setVisible(true);
                BEDret_text_4.setVisible(true);
                Dret_text_4.setVisible(true);
                ProDose_4.setVisible(true);

                try {
                    double RiskVal = Double.parseDouble(RiskOfMyel_4.getText());
                    if (RiskVal > 0 && RiskVal < 100) {
                        RiskVal = RiskVal;
                    } else {
                        RiskVal = 1;
                        RiskOfMyel_4.setText("1");
                    }
                    System.out.println("Risk Of Myel is " + RiskVal);
                } catch (NumberFormatException RiskVal) {
                    System.out.println("Error:" + " is not valid");
                    RiskOfMyel_4.setText("1");
                }

                try {
                    double InitalVal = Double.parseDouble(initalDose_4.getText());
                    if (InitalVal > 0) {
                        InitalVal = InitalVal;
                    } else {
                        InitalVal = 40;
                        initalDose_4.setText("40");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    initalDose_4.setText("40");
                }

                try {
                    int NumVal = Integer.parseInt(NumFrac_4.getText());
                    if (NumVal > 0) {
                        NumVal = NumVal;
                    } else {
                        NumVal = 20;
                        NumFrac_4.setText("20");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    NumFrac_4.setText("20");
                }
                
                try {
                    double RetVal = Double.parseDouble(DHIGH_4.getText());
                    if (RetVal > 0) {
                        RetVal = RetVal;
                    } else {
                        RetVal = 40;
                        DHIGH_4.setText("20");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    DHIGH_4.setText("40");

                }
                try {
                    double RetVal = Double.parseDouble(letx_4.getText());
                    if (RetVal > 0) {
                        RetVal = RetVal;
                    } else {
                        RetVal = 5;
                        letx_4.setText("5");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    letx_4.setText("5");

                }

                try {
                    double RetVal = Double.parseDouble(letu_4.getText());
                    if (RetVal > 0) {
                        RetVal = RetVal;
                    } else {
                        RetVal = 30.5;
                        letu_4.setText("30.5");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    letu_4.setText("30.5");

                }
                DecimalFormat df2 = new DecimalFormat("#.##");
                double INIT = Double.parseDouble(initalDose_4.getText());
                double FRAC = Double.parseDouble(NumFrac_4.getText());
                double k = (RBE_4_IN() * FRAC * INIT) / FRAC;
                initfrac_text_4.setText(df2.format(INIT * FRAC));

//CODE FOR THE LABELS BEDS 
                double D = BED_Rper_4(0);
                double S = shiftch_4(-1, 20);

                if (BED1_pc_human_4() > 100) {
                    warn_bed_4.setVisible(true);
                    warn_bed_4.setText("WARNING: INITIAL DOSE OVER TOLERANCE");
                    p_high_4.setVisible(false);
                    p_low_4.setVisible(false);
                    BED1_text_4.setText("NA");
                    BEDinit_text_4.setText("NA");
                    BEDR_text_4.setText("NA");
                    BEDR2_TEXT_4.setText("NA");
                    BED2_text_4.setText("NA");
                    BEDret_text_4.setText("NA");
                    Dret_text_4.setText("NA");
                    ProDose_4.setText("NA");
                    out_4.setText("NA");
                } else if (p_eqn_4(D, S) > 0.999) {
                    p_high_4.setVisible(true);
                    p_high_4.setText("WARNING: RISK GREATER THAN 99.9%");
                    BED1_text_4.setText("NA");
                    BEDinit_text_4.setText("NA");
                    BEDR_text_4.setText("NA");
                    BEDR2_TEXT_4.setText("NA");
                    BED2_text_4.setText("NA");
                    BEDret_text_4.setText("NA");
                    Dret_text_4.setText("NA");
                    ProDose_4.setText("NA");
                    out_4.setText("NA");
                    warn_bed_4.setVisible(false);
                    p_low_4.setVisible(false);
                } else if (p_eqn_4(D, S) < 1e-5) {
                    p_low_4.setVisible(true);
                    p_low_4.setText("WARNING: RISK LESS THAN 0.001%");
                    BED1_text_4.setText("NA");
                    BEDinit_text_4.setText("NA");
                    BEDR_text_4.setText("NA");
                    BEDR2_TEXT_4.setText("NA");
                    BED2_text_4.setText("NA");
                    BEDret_text_4.setText("NA");
                    Dret_text_4.setText("NA");
                    out_4.setText("NA");
                    ProDose_4.setText("NA");
                    warn_bed_4.setVisible(false);
                    p_high_4.setVisible(false);
                } else {

                    initfrac_text_4.setText(df2.format(INIT * FRAC));

//CODE FOR THE LABELS BEDS
                    BED1_text_4.setText(df2.format(BED1_4(500)));
                    BEDinit_text_4.setText(df2.format((RBE_4_IN() * FRAC * INIT * (1 + (INIT * RBE_4_IN()) / 2))));
                    BEDR_text_4.setText(df2.format((BED_Rper_4(500))));
                    BEDR2_TEXT_4.setText(df2.format(BED_Rper_4(500)));
                    BED2_text_4.setText(df2.format(BED2__4(500)));
                    BEDret_text_4.setText(df2.format((BED2__4(500) * (BED_Rper_4(500))) / 100));
                    Dret_text_4.setText(df2.format(dose_4(0, 50)));
                    out_4.setText(df2.format(RBE_4_RE()));
                    ProDose_4.setText(DHIGH_4.getText());

                    warn_bed_4.setVisible(false);
                    p_high_4.setVisible(false);
                    p_low_4.setVisible(false);
                    out_4.setVisible(true);
                    BED1_text_4.setVisible(true);
                    BEDinit_text_4.setVisible(true);
                    BEDR_text_4.setVisible(true);
                    BEDR2_TEXT_4.setVisible(true);
                    BED2_text_4.setVisible(true);
                    BEDret_text_4.setVisible(true);
                    Dret_text_4.setVisible(true);
                    ProDose_4.setVisible(true);
                }

                double BED2Array_4[] = new double[101];
                for (int j = 0; j < 101; j++) {

                    double value1 = BED2_FINAL_4(j);
                    BED2Array_4[j] = value1;
                }

                for (int i = 0; i < 101; i++) {
                    series9_4.getData().add(new XYChart.Data(i, BED2Array_4[i]));
                }
                series10_4.getData().add(new XYChart.Data(BED1_pc_4(), BED21_pc_4()));
                series11_4.getData().add(new XYChart.Data(BED1_pc_4(), BED22_pc_4()));

                series12_4.getData().add(new XYChart.Data(BED1_pc_4(), BED23_pc_4()));

                series13_4.getData().add(new XYChart.Data(BED1_pc_human_4(), BED2_FINAL_4(BED1_pc_human_4())));
                series14_4.getData().add(new XYChart.Data(0, BED2_FINAL_4(BED1_pc_human_4())));
                series14_4.getData().add(new XYChart.Data(BED1_pc_human_4(), BED2_FINAL_4(BED1_pc_human_4())));

                series15_4.getData().add(new XYChart.Data(BED1_pc_human_4(), 0));
                series15_4.getData().add(new XYChart.Data(BED1_pc_human_4(), BED2_FINAL_4(BED1_pc_human_4())));

                chart2_4.getData().addAll(series9_4, series10_4, series11_4, series12_4, series13_4, series14_4, series15_4);

                System.out.println("Initial RBE = " + RBE_4_IN());

                long endTime = System.nanoTime();
                long totalTime = endTime - startTime;
                System.out.println("Total time for calculation " + totalTime / 1e9 + " seconds");
            }

        });

        ///  CALCULATOR BUTTON FOR TAB 2//////////////////////////////////////////////////
        Calculate_2.setOnAction(new EventHandler<ActionEvent>() {

            public double alpha_u_2() {
                return (10.57 / 3.92) * (1 - Math.exp(-3.92 * alpha_low));
            }

            public double Ahi_2() {
                double letx = Double.parseDouble(letx_2.getText());
                double letu = Double.parseDouble(letu_2.getText());

                return alpha_low + (alpha_u_2() - alpha_low) * (letx - 0.22) / (letu - 0.22);
            }

            public double beta_u_2() {
                return 0.06 * (1 - Math.exp(-50 * beta_low));
            }

            public double Bhi_2() {
                double letx = Double.parseDouble(letx_2.getText());
                double letu = Double.parseDouble(letu_2.getText());

                return beta_low + (beta_u_2() - beta_low) * (letx - 0.22) / (letu - 0.22);

            }

            public double d_low_2() {
                double d_hi = Double.parseDouble(DHIGH_2.getText());

                return 1 / (2 * beta_low) * (-alpha_low + Math.pow(alpha_low * alpha_low + 4 * Ahi_2() * beta_low * d_hi + 4 * Bhi_2() * beta_low * d_hi * d_hi, 0.5));

            }

            public double RBE_2() {
                double d_hi = Double.parseDouble(DHIGH_2.getText());
                if (RBE_CHECKBOX_2.isSelected()) {
                    return 1.1;
                } else {
                    return d_low_2() / d_hi;
                }

            }
////////////////////////// TAB2 EQNS SAME AS PHOTON /////////////////////////////

            public double probit0_2(double Dinit) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((Dinit) / D50_0) - 1))))));
            }

            public double Dret_0_2(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit0_2(a) * probit0_2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit0_2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit0_2(c) * probit0_2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit1_2(double Dret1) {
                double gamma50_1 = (double) 9.5675;
                double D50_1 = (double) 64.3842;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((Dret1) / D50_1) - 1))))));  // Need the shift factor for conservative
            }

            public double Dret_1_2(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit1_2(a) * probit1_2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit1_2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit1_2(c) * probit1_2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit2_2(double Dret2) {
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((Dret2) / D50_2) - 1))))));
            }

            public double Dret_2_2(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit2_2(a) * probit2_2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit2_2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit2_2(c) * probit2_2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double probit3_2(double Dret3) {
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((Dret3) / D50_3) - 1))))));
            }

            public double Dret_3_2(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit3_2(a) * probit3_2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit3_2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit3_2(c) * probit3_2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }
            //CALCULATING BEDS

            //////////////////Shifting for conservative factors for Human data/////////////////////////
            public double shifth0_2(double s) {
                double gamma50_0 = (double) 11.3764;
                double C = (double) PercentageSlider_2.getValue();
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + 54.8 * (1 - (C) * 0.01)) / D50_0) - 1))))));
            }

            public double shiftch_2(double a, double b) {
                double EPSILON = (double) 0.01;

                if (shifth0_2(a) * shifth0_2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shifth0_2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shifth0_2(c) * shifth0_2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftm0_2(double s, double d) {
                double gamma50_0 = (double) 11.3764;
                double C = (double) PercentageSlider_2.getValue();
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + d * (1 - (C) * 0.01)) / D50_0) - 1))))));  
            }

            public double shiftc_2(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_0_2(30, 70);
                //double D = BED_Rper(0);
                //double shift = shiftch(-1,20);

                if (shiftm0_2(a, d) * shiftm0_2(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftm0_2(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftm0_2(c, d) * shiftm0_2(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_1_2(double s, double d) {
                double gamma50_1 = (double) 9.5675;
                double C = (double) PercentageSlider_2.getValue();
                double D50_1 = (double) 64.3842;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((s + d * (1 - (C) * 0.01)) / D50_1) - 1))))));  
            }

            public double shift1_2(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_1_2(30, 70);

                if (shiftD_1_2(a, d) * shiftD_1_2(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_1_2(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_1_2(c, d) * shiftD_1_2(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_2_2(double s, double d) {
                double C = (double) PercentageSlider_2.getValue();
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;
               

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((s + d * (1 - (C) * 0.01)) / D50_2) - 1))))));  
            }

            public double shift2_2(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_2_2(30, 70);

                if (shiftD_2_2(a, d) * shiftD_2_2(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_2_2(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_2_2(c, d) * shiftD_2_2(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_3_2(double s, double d) {
                double C = (double) PercentageSlider_2.getValue();
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((s + d * (1 - (C) * 0.01)) / D50_3) - 1))))));  
            }

            public double shift3_2(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_3_2(30, 70);

                if (shiftD_3_2(a, d) * shiftD_3_2(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_3_2(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_3_2(c, d) * shiftD_3_2(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            ///////////////////////////////////////New Dret_0 ....Dret_3 with shift added to them//////////////
            public double probit0shift_2(double Dinit, double s) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_2.getText());

                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + Dinit) / D50_0) - 1))))));
                //return (double) (p_eqn_2(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_0*(((s+Dinit)/D50_0)-1)))))); 
            }

            public double Dret_0shift_2(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shiftc_2((double) -0.1, 15);
                // double shift = shiftch_2((double) -0.1,20);
                //  double d0 = BED_Rper_2(0);

                if (probit0shift_2(a, s) * probit0shift_2(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit0shift_2(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit0shift_2(c, s) * probit0shift_2(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit1shift_2(double Dret1, double s) {
                double gamma50_1 = (double) 9.5675;
                double D50_1 = (double) 64.3842;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_2.getText());

                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((s + Dret1) / D50_1) - 1))))));
                // return (double) (p_eqn_2(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_1*(((s+Dret1)/D50_1)-1))))));  
            }

            public double Dret_1shift_2(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift1_2((double) -0.1, 15);
                //double shift = shiftch_2((double) -0.1,20);
                //double d0 = BED_Rper_2(0);

                if (probit1shift_2(a, s) * probit1shift_2(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit1shift_2(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit1shift_2(c, s) * probit1shift_2(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit2shift_2(double Dret1, double s) {
                double gamma50_2 = (double) 10.7338;
                // double C = PercentageSlider.getValue();
                double D50_2 = (double) 72.2328;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_2.getText());
                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((s + Dret1) / D50_2) - 1))))));
                // return (double) (p_eqn_2(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_2*(((s+Dret1)/D50_2)-1))))));  
            }

            public double Dret_2shift_2(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift2_2((double) -0.1, 15);
                // double shift = shiftch_2((double) -0.1,20);
                //double d0 = BED_Rper_2(0);

                if (probit2shift_2(a, s) * probit2shift_2(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit2shift_2(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit2shift_2(c, s) * probit2shift_2(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit3shift_2(double Dret1, double s) {
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_2.getText());
                
                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((s + Dret1) / D50_3) - 1))))));
                // return (double) (p_eqn_2(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_3*(((s+Dret1)/D50_3)-1)))))); 
            }

            public double Dret_3shift_2(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift3_2((double) -0.5, 15);
                // double shift = shiftch_2((double) -0.1,20);
                // double d0 = BED_Rper_2(0);

                if (probit3shift_2(a, s) * probit3shift_2(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit3shift_2(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit3shift_2(c, s) * probit3shift_2(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double HU_totaleq_2(double d, double s) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                double P = (double) (0.01 * Double.parseDouble(RiskOfMyel_2.getText()));
                
                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + d) / D50_0) - 1))))));
            }

            public double Dtol_Hu_2(double a, double b) {
                double EPSILON = (double) 0.001;
                double s = shiftch_2((double) -0.1, 20);

                if (HU_totaleq_2(a, s) * HU_totaleq_2(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (HU_totaleq_2(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (HU_totaleq_2(c, s) * HU_totaleq_2(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            ///////////////////////////////BED PERCENTAGE CALCULATIONS//////////////////////////////////////////////  
            public double BED1_pc_human_2() {
                double INIT = Double.parseDouble(initalDose_2.getText());
                double FRAC = Double.parseDouble(NumFrac_2.getText());
                double k = INIT / FRAC;

                return (INIT * (1 + k / 2) / (Dtol_Hu_2(0, 120) * 2)) * 100;
            }

            public double BED1_pc_2() {
                return (44 / Dret_0shift_2(0, 120)) * 100;
               
            }

            public double BED21_pc_2() {
                return (Dret_1shift_2(30, 80) / Dret_0shift_2(0, 80)) * 100;
            }

            public double BED22_pc_2() {
                return (Dret_2shift_2(30, 80) / Dret_0shift_2(0, 80)) * 100;
            }

            public double BED23_pc_2() {
                return (Dret_3shift_2(30, 80) / Dret_0shift_2(30, 80)) * 100;
            }

            ///////////////// P_CALC FROM MATLAB ///////////////////////////////////////////////////////////////////
            public double p_eqn_2(double d, double shiftch) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;

                return Double.parseDouble(RiskOfMyel_2.getText()) / 100;
                /* if (Double.parseDouble(RiskOfMyel_2.getText())==1){
            return (double) 0.01;}
        
        else if (Double.parseDouble(RiskOfMyel_2.getText())== 0.1){
        return (double) 0.0010001470751888064;}
    
        else 
        return (double) (0.5*(1+erf((double) (0.70710678118*(gamma50_0*((((Dtol_Hu_2(0,120))+shiftch)/D50_0)-1))))));    
                 */
               
            }

            ///////////////////////////////////////////////////////////////////////////////////  
            //BED OF PERCENTAGE R - NOMINAL VALUE
            public double BED_Rper_2(double a) {
                return Dtol_Hu_2(0, 120) * 2;
                //return Dret_0shift(0,200)*2;
            }
        

            public double BED1_2(double a) {
                double INIT = Double.parseDouble(initalDose_2.getText());
                double FRAC = Double.parseDouble(NumFrac_2.getText());
                double k = INIT / FRAC;
                return ((INIT * (1 + k / 2)) / (BED_Rper_2(a))) * 100;

            }
            /////////////////////GETTING THE VALUES FOR r(1),r(2) and r(3)//////////////////////////////////////

            public double BED2_r1_2(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double B1 = BED1_pc_2();
                
                return (double) (BED21_pc_2() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
               
            }

            public double r_1_2(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r1_2(a) * BED2_r1_2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r1_2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r1_2(c) * BED2_r1_2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double BED2_r2_2(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double B1 = BED1_pc_2();
             
                return (double) (BED22_pc_2() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
               
            }

            public double r_2_2(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r2_2(a) * BED2_r2_2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r2_2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r2_2(c) * BED2_r2_2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double BED2_r3_2(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double B1 = BED1_pc_2();
                
                return (double) (BED23_pc_2() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
               
            }

            public double r_3_2(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r3_2(a) * BED2_r3_2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r3_2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r3_2(c) * BED2_r3_2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }
//DEFINING THE r(t) FUNCTION - MAKE MORE EFFICIENT

            public double r_2(double t) {
                double Tiro = (double) 0.19;
                double m;
                double r_1 = r_1_2(0, 200);
                double r_2 = r_2_2(0, 200);
                double r_3 = r_3_2(0, 200);

                double a = 3 * (Tiro * r_1) / (Tiro - 1) - 3 * (Tiro * r_2) / (Tiro - 2) + (Tiro * r_3) / (Tiro - 3);
                double b = (double) (-0.5 * ((5 * Tiro + 6) * r_1) / (Tiro - 1) + (4 * Tiro + 3) * r_2 / (Tiro - 2) - 0.5 * (3 * Tiro + 2) * (r_3) / (Tiro - 3));
                double c = (double) (0.5 * (Tiro + 5) * (r_1) / (Tiro - 1) - (Tiro + 4) * (r_2) / (Tiro - 2) + 0.5 * (Tiro + 3) * (r_3) / (Tiro - 3));
                double d = (double) (-0.5 * (r_1) / (Tiro - 1) + (r_2) / (Tiro - 2) - 0.5 * (r_3) / (Tiro - 3));
                if (t < Tiro) {
                    return 0;
                } else {
                    return m = (double) (a + b * t + c * Math.pow(t, 2) + d * Math.pow(t, 3));
                }

            }
            //////////// BED2 for the graph ////////////////////////////////////////

            public double BED2_FINAL_2(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double t = (double) NumOfYearsSlider_2.getValue();

                if (a < 100) {
                    return (double) (100 * (1 - a * 0.01) * (1 + (Math.pow(1 - a * 0.01, -r_2(t) / (r_2(t) + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (a - B / (1 + s_1 * r_2(t)))))));
                } else {
                    return 0;
                }
            }
            ////////////////////////BED2 FOR TEXT LABEL//////////////////////////////////////////////

            public double BED2__2(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double t = (double) NumOfYearsSlider_2.getValue();
                double B1 = BED1_2(0);

                return (double) (100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -r_2(t) / (r_2(t) + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * r_2(t)))))));

            }
            //////// Function to find the Dret/n(r) ////////////////////////////

            public double dosefcn_2(double n) {
                double D = Double.parseDouble(DHIGH_2.getText());
                if (RBE_CHECKBOX_2.isSelected()) {
                    double d = D * RBE_2();
                    return (double) (BED2__2(500) * BED_Rper_2(500) * 0.01 - (n * d + n * d * d / 2));

                } else {
                    double d = D * RBE_2();
                    return (double) (BED2__2(500) * BED_Rper_2(500) * 0.01 - (n * d + n * d * d / 2));
                }

            }

            public double dose_2(double a, double b) {
                double EPSILON = (double) 0.001;

                if (dosefcn_2(a) * dosefcn_2(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (dosefcn_2(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (dosefcn_2(c) * dosefcn_2(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }

                return Math.floor(c);

            }

            @Override
            public void handle(ActionEvent event) {
                long startTime = System.nanoTime();
                
               
                series9_2.getData().clear();
                series10_2.getData().clear();
                series11_2.getData().clear();
                series12_2.getData().clear();
                series13_2.getData().clear();
                series14_2.getData().clear();
                series15_2.getData().clear();

                warn_bed_2.setVisible(false);
                p_high_2.setVisible(false);
                p_low_2.setVisible(false);
                out_2.setVisible(true);
                BED1_text_2.setVisible(true);
                BEDinit_text_2.setVisible(true);
                BEDR_text_2.setVisible(true);
                BEDR2_TEXT_2.setVisible(true);
                BED2_text_2.setVisible(true);
                BEDret_text_2.setVisible(true);
                Dret_text_2.setVisible(true);
                ProDose_2.setVisible(true);

                try {
                    double RiskVal = Double.parseDouble(RiskOfMyel_2.getText());
                    if (RiskVal > 0 && RiskVal < 100) {
                        RiskVal = RiskVal;
                    } else {
                        RiskVal = 1;
                        RiskOfMyel_2.setText("1");
                    }
                    System.out.println("Risk Of Myel is " + RiskVal);
                } catch (NumberFormatException RiskVal) {
                    System.out.println("Error:" + " is not valid");
                    RiskOfMyel_2.setText("1");
                }

                try {
                    double InitalVal = Double.parseDouble(initalDose_2.getText());
                    if (InitalVal > 0) {
                        InitalVal = InitalVal;
                    } else {
                        InitalVal = 40;
                        initalDose_2.setText("40");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    initalDose_2.setText("40");
                }

                try {
                    int NumVal = Integer.parseInt(NumFrac_2.getText());
                    if (NumVal > 0) {
                        NumVal = NumVal;
                    } else {
                        NumVal = 20;
                        NumFrac_2.setText("20");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    NumFrac_2.setText("20");
                }

                try {
                    double RetVal = Double.parseDouble(DHIGH_2.getText());
                    if (RetVal > 0) {
                        RetVal = RetVal;
                    } else {
                        RetVal = 40;
                        DHIGH_2.setText("20");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    DHIGH_2.setText("40");

                }
                try {
                    double RetVal = Double.parseDouble(letx_2.getText());
                    if (RetVal > 0) {
                        RetVal = RetVal;
                    } else {
                        RetVal = 5;
                        letx_2.setText("5");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    letx_2.setText("5");

                }

                try {
                    double RetVal = Double.parseDouble(letu_2.getText());
                    if (RetVal > 0) {
                        RetVal = RetVal;
                    } else {
                        RetVal = 30.5;
                        letu_2.setText("30.5");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    letu_2.setText("30.5");

                }
                DecimalFormat df2 = new DecimalFormat("#.##");
                double INIT = Double.parseDouble(initalDose_2.getText());
                double FRAC = Double.parseDouble(NumFrac_2.getText());
                double k = INIT / FRAC;
                initfrac_text_2.setText(df2.format(k));

//CODE FOR THE LABELS BEDS 
            
                double D = BED_Rper_2(0);
                double S = shiftch_2(-1, 20);

                if (BED1_pc_human_2() > 100) {
                    warn_bed_2.setVisible(true);
                    warn_bed_2.setText("WARNING: INITIAL DOSE OVER TOLERANCE");
                    p_high_2.setVisible(false);
                    p_low_2.setVisible(false);
                    BED1_text_2.setText("NA");
                    BEDinit_text_2.setText("NA");
                    BEDR_text_2.setText("NA");
                    BEDR2_TEXT_2.setText("NA");
                    BED2_text_2.setText("NA");
                    BEDret_text_2.setText("NA");
                    Dret_text_2.setText("NA");
                    ProDose_2.setText("NA");
                    out_2.setText("NA");
                } else if (p_eqn_2(D, S) > 0.999) {
                    p_high_2.setVisible(true);
                    p_high_2.setText("WARNING: RISK GREATER THAN 99.9%");
                    BED1_text_2.setText("NA");
                    BEDinit_text_2.setText("NA");
                    BEDR_text_2.setText("NA");
                    BEDR2_TEXT_2.setText("NA");
                    BED2_text_2.setText("NA");
                    BEDret_text_2.setText("NA");
                    Dret_text_2.setText("NA");
                    ProDose_2.setText("NA");
                    out_2.setText("NA");
                    warn_bed_2.setVisible(false);
                    p_low_2.setVisible(false);
                } else if (p_eqn_2(D, S) < 1e-5) {
                    p_low_2.setVisible(true);
                    p_low_2.setText("WARNING: RISK LESS THAN 0.001%");
                    BED1_text_2.setText("NA");
                    BEDinit_text_2.setText("NA");
                    BEDR_text_2.setText("NA");
                    BEDR2_TEXT_2.setText("NA");
                    BED2_text_2.setText("NA");
                    BEDret_text_2.setText("NA");
                    Dret_text_2.setText("NA");
                    out_2.setText("NA");
                    ProDose_2.setText("NA");
                    warn_bed_2.setVisible(false);
                    p_high_2.setVisible(false);
                } else {

                    initfrac_text_2.setText(df2.format(k));

//CODE FOR THE LABELS BEDS
                    BED1_text_2.setText(df2.format(BED1_2(500)));
                    BEDinit_text_2.setText(df2.format((INIT * (1 + k / 2))));
                    BEDR_text_2.setText(df2.format((BED_Rper_2(500))));
                    BEDR2_TEXT_2.setText(df2.format(BED_Rper_2(500)));
                    BED2_text_2.setText(df2.format(BED2__2(500)));
                    BEDret_text_2.setText(df2.format((BED2__2(500) * (BED_Rper_2(500))) / 100));
                    Dret_text_2.setText(df2.format(dose_2(0, 50)));
                    out_2.setText(df2.format(RBE_2()));
                    ProDose_2.setText(DHIGH_2.getText());

                    warn_bed_2.setVisible(false);
                    p_high_2.setVisible(false);
                    p_low_2.setVisible(false);
                    out_2.setVisible(true);
                    BED1_text_2.setVisible(true);
                    BEDinit_text_2.setVisible(true);
                    BEDR_text_2.setVisible(true);
                    BEDR2_TEXT_2.setVisible(true);
                    BED2_text_2.setVisible(true);
                    BEDret_text_2.setVisible(true);
                    Dret_text_2.setVisible(true);
                    ProDose_2.setVisible(true);
                }

                double BED2Array_2[] = new double[101];
                for (int j = 0; j < 101; j++) {

                    double value1 = BED2_FINAL_2(j);
                    BED2Array_2[j] = value1;
                }

                for (int i = 0; i < 101; i++) {
                    series9_2.getData().add(new XYChart.Data(i, BED2Array_2[i]));
                }
                series10_2.getData().add(new XYChart.Data(BED1_pc_2(), BED21_pc_2()));
                series11_2.getData().add(new XYChart.Data(BED1_pc_2(), BED22_pc_2()));

                series12_2.getData().add(new XYChart.Data(BED1_pc_2(), BED23_pc_2()));

                series13_2.getData().add(new XYChart.Data(BED1_pc_human_2(), BED2_FINAL_2(BED1_pc_human_2())));
                series14_2.getData().add(new XYChart.Data(0, BED2_FINAL_2(BED1_pc_human_2())));
                series14_2.getData().add(new XYChart.Data(BED1_pc_human_2(), BED2_FINAL_2(BED1_pc_human_2())));

                series15_2.getData().add(new XYChart.Data(BED1_pc_human_2(), 0));
                series15_2.getData().add(new XYChart.Data(BED1_pc_human_2(), BED2_FINAL_2(BED1_pc_human_2())));

                chart2_2.getData().addAll(series9_2, series10_2, series11_2, series12_2, series13_2, series14_2, series15_2);
                
                long endTime = System.nanoTime();
                long totalTime = endTime - startTime;
                System.out.println("Total time for calculation " + totalTime / 1e9 + " seconds");
            }
        });

        /////////////////TAB 3 CAL///////////////////////////////////////////////////////////
        Calculate_3.setOnAction(new EventHandler<ActionEvent>() {

            public double alpha_u_3_IN() {
                return (10.57 / 3.92) * (1 - Math.exp(-3.92 * alpha_low));
            }

            public double Ahi_3_IN() {
                double letx = Double.parseDouble(letx_3.getText());
                double letu = Double.parseDouble(letu_3.getText());

                return alpha_low + (alpha_u_3_IN() - alpha_low) * (letx - 0.22) / (letu - 0.22);
            }

            public double beta_u_3_IN() {
                return 0.06 * (1 - Math.exp(-50 * beta_low));
            }

            public double Bhi_3_IN() {
                double letx = Double.parseDouble(letx_3.getText());
                double letu = Double.parseDouble(letu_3.getText());

                return beta_low + (beta_u_3_IN() - beta_low) * (letx - 0.22) / (letu - 0.22);

            }

            public double d_low_2_3_IN() {
                double d_hi = Double.parseDouble(initalDose_3.getText());

                return 1 / (2 * beta_low) * (-alpha_low + Math.pow(alpha_low * alpha_low + 4 * Ahi_3_IN() * beta_low * d_hi + 4 * Bhi_3_IN() * beta_low * d_hi * d_hi, 0.5));

            }

            public double RBE_3_IN() {
                double d_hi = Double.parseDouble(initalDose_3.getText());
                DecimalFormat df2 = new DecimalFormat("#.##");
                double m;
                if (RBE_CHECKBOX_3.isSelected()) {
                    return 1.1;
                } else {
                    m = (d_low_2_3_IN() / d_hi);
                }
                return Math.round(m * 100d) / 100d;

            }

            public double probit0_3(double Dinit) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                
                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((Dinit) / D50_0) - 1))))));
            }

            public double Dret_0_3(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit0_3(a) * probit0_3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit0_3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit0_3(c) * probit0_3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit1_3(double Dret1) {
                double gamma50_1 = (double) 9.5675;
                double D50_1 = (double) 64.3842;
             
                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((Dret1) / D50_1) - 1))))));  // Need the shift factor for conservative
            }

            public double Dret_1_3(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit1_3(a) * probit1_3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit1_3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit1_3(c) * probit1_3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit2_3(double Dret2) {
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;
                
                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((Dret2) / D50_2) - 1))))));
            }

            public double Dret_2_3(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit2_3(a) * probit2_3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit2_3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit2_3(c) * probit2_3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double probit3_3(double Dret3) {
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;
               
                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((Dret3) / D50_3) - 1))))));
            }

            public double Dret_3_3(double a, double b) {
                double EPSILON = (double) 0.01;

                if (probit3_3(a) * probit3_3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit3_3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit3_3(c) * probit3_3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }
            //CALCULATING BEDS

            //////////////////Shifting for conservative factors for Human data/////////////////////////
            public double shifth0_3(double s) {
                double gamma50_0 = (double) 11.3764;
                double C = (double) PercentageSlider_3.getValue();
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + 54.8 * (1 - (C) * 0.01)) / D50_0) - 1))))));  
            }

            public double shiftch_3(double a, double b) {
                double EPSILON = (double) 0.01;

                if (shifth0_3(a) * shifth0_3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shifth0_3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shifth0_3(c) * shifth0_3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftm0_3(double s, double d) {
                double gamma50_0 = (double) 11.3764;
                double C = (double) PercentageSlider_3.getValue();
                double D50_0 = (double) 76.5571;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + d * (1 - (C) * 0.01)) / D50_0) - 1))))));  
            }

            public double shiftc_3(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_0_3(30, 70);
                //double D = BED_Rper(0);
                //double shift = shiftch(-1,20);

                if (shiftm0_3(a, d) * shiftm0_3(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftm0_3(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftm0_3(c, d) * shiftm0_3(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_1_3(double s, double d) {
                double gamma50_1 = (double) 9.5675;
                double C = (double) PercentageSlider_3.getValue();
                double D50_1 = (double) 64.3842;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((s + d * (1 - (C) * 0.01)) / D50_1) - 1)))))); 
            }

            public double shift1_3(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_1_3(30, 70);

                if (shiftD_1_3(a, d) * shiftD_1_3(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_1_3(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_1_3(c, d) * shiftD_1_3(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_2_3(double s, double d) {
                double C = (double) PercentageSlider_3.getValue();
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;
               
                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((s + d * (1 - (C) * 0.01)) / D50_2) - 1)))))); 
            }

            public double shift2_3(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_2_3(30, 70);

                if (shiftD_2_3(a, d) * shiftD_2_3(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_2_3(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_2_3(c, d) * shiftD_2_3(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double shiftD_3_3(double s, double d) {
                double C = (double) PercentageSlider_3.getValue();
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;

                return (double) (0.01 - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((s + d * (1 - (C) * 0.01)) / D50_3) - 1)))))); 
            }

            public double shift3_3(double a, double b) {
                double EPSILON = (double) 0.01;
                double d = Dret_3_3(30, 70);

                if (shiftD_3_3(a, d) * shiftD_3_3(b, d) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (shiftD_3_3(c, d) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (shiftD_3_3(c, d) * shiftD_3_3(a, d) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            ///////////////////////////////////////New Dret_0 ....Dret_3 with shift added to them//////////////
            public double probit0shift_3(double Dinit, double s) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_3.getText());

                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + Dinit) / D50_0) - 1))))));
                // return (double) (p_eqn_3(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_0*(((s+Dinit)/D50_0)-1)))))); 
            }

            public double Dret_0shift_3(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shiftc_3((double) -0.1, 15);
                //  double shift = shiftch_3((double) -0.1,20);
                //   double d0 = BED_Rper_3(0);

                if (probit0shift_3(a, s) * probit0shift_3(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit0shift_3(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit0shift_3(c, s) * probit0shift_3(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit1shift_3(double Dret1, double s) {
                double gamma50_1 = (double) 9.5675;
                double D50_1 = (double) 64.3842;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_3.getText());

                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_1 * (((s + Dret1) / D50_1) - 1))))));
                // return (double) (p_eqn_3(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_1*(((s+Dret1)/D50_1)-1)))))); 
            }

            public double Dret_1shift_3(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift1_3((double) -0.1, 15);
                //  double shift = shiftch_3((double) -0.1,20);
                //  double d0 = BED_Rper_3(0);

                if (probit1shift_3(a, s) * probit1shift_3(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit1shift_3(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit1shift_3(c, s) * probit1shift_3(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit2shift_3(double Dret1, double s) {
                double gamma50_2 = (double) 10.7338;
                double D50_2 = (double) 72.2328;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_3.getText());

                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_2 * (((s + Dret1) / D50_2) - 1))))));
                // return (double) (p_eqn_3(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_2*(((s+Dret1)/D50_2)-1)))))); 
            }

            public double Dret_2shift_3(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift2_3((double) -0.1, 15);
                //  double shift = shiftch_3((double) -0.1,20);
                // double d0 = BED_Rper_3(0);

                if (probit2shift_3(a, s) * probit2shift_3(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit2shift_3(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit2shift_3(c, s) * probit2shift_3(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double probit3shift_3(double Dret1, double s) {
                double gamma50_3 = (double) 11.1428;
                double D50_3 = (double) 74.9850;
                double P = 0.01 * Double.parseDouble(RiskOfMyel_3.getText());

                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_3 * (((s + Dret1) / D50_3) - 1))))));
                //return (double) (p_eqn_3(d,shift) - 0.5*(1+erf((double) (0.70710678118*(gamma50_3*(((s+Dret1)/D50_3)-1))))));  
            }

            public double Dret_3shift_3(double a, double b) {
                double EPSILON = (double) 0.01;
                double s = shift3_3((double) -0.5, 15);
                // double shift = shiftch_3((double) -0.1,20);
                // double d0 = BED_Rper_3(0);

                if (probit3shift_3(a, s) * probit3shift_3(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (probit3shift_3(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (probit3shift_3(c, s) * probit3shift_3(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            public double HU_totaleq_3(double d, double s) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                double P = (double) (0.01 * Double.parseDouble(RiskOfMyel_3.getText()));
                
                return (double) (P - 0.5 * (1 + erf((double) (0.70710678118 * (gamma50_0 * (((s + d) / D50_0) - 1))))));
            }

            public double Dtol_Hu_3(double a, double b) {
                double EPSILON = (double) 0.001;
                double s = shiftch_3((double) -0.1, 20);

                if (HU_totaleq_3(a, s) * HU_totaleq_3(b, s) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (HU_totaleq_3(c, s) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (HU_totaleq_3(c, s) * HU_totaleq_3(a, s) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;
            }

            ///////////////////////////////Percentage BED2 from orginal paper//////////////////////////////////////////////  
            public double BED1_pc_human_3() {
                double INIT = Double.parseDouble(initalDose_3.getText());
                double FRAC = Double.parseDouble(NumFrac_3.getText());
                double k = RBE_3_IN() * INIT;

                return (k * FRAC * (1 + k / 2) / (Dtol_Hu_3(0, 120) * 2)) * 100;
            }

            public double BED1_pc_3() {
                return (44 / Dret_0shift_3(0, 120)) * 100;
                
            }

            public double BED21_pc_3() {
                return (Dret_1shift_3(30, 80) / Dret_0shift_3(0, 80)) * 100;
            }

            public double BED22_pc_3() {
                return (Dret_2shift_3(30, 80) / Dret_0shift_3(0, 80)) * 100;
            }

            public double BED23_pc_3() {
                return (Dret_3shift_3(30, 80) / Dret_0shift_3(30, 80)) * 100;
            }

            ///////////////// P_CALC FROM MATLAB ///////////////////////////////////////////////////////////////////
            public double p_eqn_3(double d, double shiftch) {
                double gamma50_0 = (double) 11.3764;
                double D50_0 = (double) 76.5571;
                return Double.parseDouble(RiskOfMyel_3.getText()) / 100;
                /*
        if (Double.parseDouble(RiskOfMyel_3.getText())==1){
            return (double) 0.01;}
        
        else if (Double.parseDouble(RiskOfMyel_3.getText())== 0.1){
        return (double) 0.0010001470751888064;}
    
        else 
        return (double) (0.5*(1+erf((double) (0.70710678118*(gamma50_0*((((Dtol_Hu_3(0,120))+shiftch)/D50_0)-1))))));    
                 */
                
            }

            ///////////////////////////////////////////////////////////////////////////////////  
            //BED OF PERCENTAGE R - NOMINAL VALUE
            public double BED_Rper_3(double a) {
                return Dtol_Hu_3(0, 120) * 2;
            }
           
            public double BED1_3(double a) {
                double INIT = Double.parseDouble(initalDose_3.getText());
                double FRAC = Double.parseDouble(NumFrac_3.getText());
                double k = RBE_3_IN() * INIT;
                
                return ((k * FRAC * (1 + (k) / 2)) / (BED_Rper_3(a))) * 100;
               

            }
            /////////////////////GETTING THE VALUES FOR r(1),r(2) and r(3)//////////////////////////////////////

            public double BED2_r1_3(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double B1 = BED1_pc_3();

                return (double) (BED21_pc_3() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
            }

            public double r_1_3(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r1_3(a) * BED2_r1_3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r1_3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r1_3(c) * BED2_r1_3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double BED2_r2_3(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double B1 = BED1_pc_3();
                

                return (double) (BED22_pc_3() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
            }

            public double r_2_3(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r2_3(a) * BED2_r2_3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r2_3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r2_3(c) * BED2_r2_3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }

            public double BED2_r3_3(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double B1 = BED1_pc_3();

                return (double) (BED23_pc_3() - 100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -a / (a + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * a))))));
            }

            public double r_3_3(double a, double b) {
                double EPSILON = (double) 0.001;

                if (BED2_r3_3(a) * BED2_r3_3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (BED2_r3_3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (BED2_r3_3(c) * BED2_r3_3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }
                return c;

            }
//DEFINING THE r(t) FUNCTION - MAKE MORE EFFICIENT

            public double r_3(double t) {
                double Tiro = (double) 0.19;
                double m;
                double r_1 = r_1_3(0, 200);
                double r_2 = r_2_3(0, 200);
                double r_3 = r_3_3(0, 200);

                double a = 3 * (Tiro * r_1) / (Tiro - 1) - 3 * (Tiro * r_2) / (Tiro - 2) + (Tiro * r_3) / (Tiro - 3);
                double b = (double) (-0.5 * ((5 * Tiro + 6) * r_1) / (Tiro - 1) + (4 * Tiro + 3) * r_2 / (Tiro - 2) - 0.5 * (3 * Tiro + 2) * (r_3) / (Tiro - 3));
                double c = (double) (0.5 * (Tiro + 5) * (r_1) / (Tiro - 1) - (Tiro + 4) * (r_2) / (Tiro - 2) + 0.5 * (Tiro + 3) * (r_3) / (Tiro - 3));
                double d = (double) (-0.5 * (r_1) / (Tiro - 1) + (r_2) / (Tiro - 2) - 0.5 * (r_3) / (Tiro - 3));
                if (t < Tiro) {
                    return 0;
                } else {
                    return m = (double) (a + b * t + c * Math.pow(t, 2) + d * Math.pow(t, 3));
                }

            }
            //////////// BED2 for the graph ////////////////////////////////////////

            public double BED2_FINAL_3(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double t = (double) NumOfYearsSlider_3.getValue();

                if (a < 100) {
                    return (double) (100 * (1 - a * 0.01) * (1 + (Math.pow(1 - a * 0.01, -r_3(t) / (r_3(t) + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (a - B / (1 + s_1 * r_3(t)))))));
                } else {
                    return 0;
                }
            }
            ////////////////////////BED2 FOR TEXT LABEL//////////////////////////////////////////////

            public double BED2__3(double a) {
                double B = 35;
                double s_0 = 0.15;
                double s_1 = 0.1;
                double t = (double) NumOfYearsSlider_3.getValue();
                double B1 = BED1_3(0);

                return (double) (100 * (1 - B1 * 0.01) * (1 + (Math.pow(1 - B1 * 0.01, -r_3(t) / (r_3(t) + 1)) - 1) * 0.5 * (1 + Math.tanh(s_0 * (B1 - B / (1 + s_1 * r_3(t)))))));

            }
            //////// Function to find the Dret/n(r) ////////////////////////////

            public double dosefcn_3(double d) {
                double n = Double.parseDouble(RetreatFrac_3.getText());
                

                return (double) (BED2__3(500) * BED_Rper_3(500) * 0.01 - (n * d + n * d * d / 2));

            }

            public double dose_3(double a, double b) {
                double EPSILON = (double) 0.001;

                if (dosefcn_3(a) * dosefcn_3(b) >= 0) {
                    System.out.println("You have not assumed"
                            + " right a and b");
                }
                double c = a;
                while ((b - a) >= EPSILON) {
                    // Find middle point 
                    c = (a + b) / 2;
                    // Check if middle point is root 
                    if (dosefcn_3(c) == 0.0) {
                        break;
                    } // Decide the side to repeat the steps 
                    else if (dosefcn_3(c) * dosefcn_3(a) < 0) {
                        b = c;
                    } else {
                        a = c;
                    }
                }

                return c;

            }


            @Override
            public void handle(ActionEvent event) {
                long startTime = System.nanoTime();

                series9_3.getData().clear();
                series10_3.getData().clear();
                series11_3.getData().clear();
                series12_3.getData().clear();
                series13_3.getData().clear();
                series14_3.getData().clear();
                series15_3.getData().clear();

                warn_bed_3.setVisible(false);
                p_high_3.setVisible(false);
                p_low_3.setVisible(false);
                out_3.setVisible(true);
                BED1_text_3.setVisible(true);
                BEDinit_text_3.setVisible(true);
                BEDR_text_3.setVisible(true);
                BEDR2_TEXT_3.setVisible(true);
                BED2_text_3.setVisible(true);
                BEDret_text_3.setVisible(true);
                Dret_text_3.setVisible(true);

               
                DecimalFormat df2 = new DecimalFormat("#.##");
                double D = BED_Rper_3(0);
                double S = shiftch_3(-1, 20);

                ///////////////////WARNINGS//////////////////////////////////////////////     
                if (BED1_pc_human_3() > 100) {
                    warn_bed_3.setVisible(true);
                    warn_bed_3.setText("WARNING: INITIAL DOSE OVER TOLERANCE");
                    p_high_3.setVisible(false);
                    p_low_3.setVisible(false);
                    BED1_text_3.setText("NA");
                    BEDinit_text_3.setText("NA");
                    BEDR_text_3.setText("NA");
                    BEDR2_TEXT_3.setText("NA");
                    BED2_text_3.setText("NA");
                    BEDret_text_3.setText("NA");
                    Dret_text_3.setText("NA");
                    out_3.setText("NA");
                } else if (p_eqn_3(D, S) > 0.999) {
                    p_high_3.setVisible(true);
                    p_high_3.setText("WARNING: RISK GREATER THAN 99.9%");
                    BED1_text_3.setText("NA");
                    BEDinit_text_3.setText("NA");
                    BEDR_text_3.setText("NA");
                    BEDR2_TEXT_3.setText("NA");
                    BED2_text_3.setText("NA");
                    BEDret_text_3.setText("NA");
                    Dret_text_3.setText("NA");
                    out_3.setText("NA");
                    warn_bed_3.setVisible(false);
                    p_low_3.setVisible(false);
                } else if (p_eqn_3(D, S) < 1e-5) {
                    p_low_3.setVisible(true);
                    p_low_3.setText("WARNING: RISK LESS THAN 0.001%");
                    BED1_text_3.setText("NA");
                    BEDinit_text_3.setText("NA");
                    BEDR_text_3.setText("NA");
                    BEDR2_TEXT_3.setText("NA");
                    BED2_text_3.setText("NA");
                    BEDret_text_3.setText("NA");
                    Dret_text_3.setText("NA");
                    out_3.setText("NA");
                    warn_bed_3.setVisible(false);
                    p_high_3.setVisible(false);
                } else {

                    double INIT = Double.parseDouble(initalDose_3.getText());
                    double FRAC = Double.parseDouble(NumFrac_3.getText());
                    double k = INIT * FRAC;
                    initfrac_text_3.setText(df2.format(k));

                    RBE_TEXT_3.setText(df2.format(RBE_3_IN()));

//CODE FOR THE LABELS BEDS
                    BED1_text_3.setText(df2.format(BED1_3(500)));
                    BEDinit_text_3.setText(df2.format(((RBE_3_IN() * FRAC * INIT * (1 + (INIT * RBE_3_IN()) / 2)))));
                    BEDR_text_3.setText(df2.format((BED_Rper_3(500))));
                    BEDR2_TEXT_3.setText(df2.format(BED_Rper_3(500)));
                    BED2_text_3.setText(df2.format(BED2__3(500)));
                    BEDret_text_3.setText(df2.format((BED2__3(500) * (BED_Rper_3(500))) / 100));
                    Dret_text_3.setText(df2.format(dose_3(0, 5)));
                    out_3.setText(df2.format(BED_Rper_3(500)));

                    warn_bed_3.setVisible(false);
                    p_high_3.setVisible(false);
                    p_low_3.setVisible(false);
                    out_3.setVisible(true);
                    BED1_text_3.setVisible(true);
                    BEDinit_text_3.setVisible(true);
                    BEDR_text_3.setVisible(true);
                    BEDR2_TEXT_3.setVisible(true);
                    BED2_text_3.setVisible(true);
                    BEDret_text_3.setVisible(true);
                    Dret_text_3.setVisible(true);

                }

// VERFICATION OF THE TEXTFIELD DATA
                try {
                    double RiskVal = Double.parseDouble(RiskOfMyel_3.getText());
                    if (RiskVal > 0 && RiskVal < 100) {
                        RiskVal = RiskVal;
                    } else {
                        RiskVal = 1;
                        RiskOfMyel_3.setText("1");
                    }
                    System.out.println("Risk Of Myel is " + RiskVal);
                } catch (NumberFormatException RiskVal) {
                    System.out.println("Error:" + " is not valid");
                    RiskOfMyel_3.setText("1");
                }

                try {
                    double InitalVal = Double.parseDouble(initalDose_3.getText());
                    if (InitalVal > 0) {
                        InitalVal = InitalVal;
                    } else {
                        InitalVal = 1.3;
                        initalDose_3.setText("1.3");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    initalDose_3.setText("40");
                }

                try {
                    int NumVal = Integer.parseInt(NumFrac_3.getText());
                    if (NumVal > 0) {
                        NumVal = NumVal;
                    } else {
                        NumVal = 20;
                        NumFrac_3.setText("20");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    NumFrac_3.setText("20");
                }

                try {
                    int RetVal = Integer.parseInt(RetreatFrac_3.getText());
                    if (RetVal > 0) {
                        RetVal = RetVal;
                    } else {
                        RetVal = 20;
                        RetreatFrac_3.setText("20");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    RetreatFrac_3.setText("20");

                }
                try {
                    double RetVal = Double.parseDouble(letx_3.getText());
                    if (RetVal > 0) {
                        RetVal = RetVal;
                    } else {
                        RetVal = 5;
                        letx_3.setText("5");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    letx_3.setText("5");

                }

                try {
                    double RetVal = Double.parseDouble(letu_3.getText());
                    if (RetVal > 0) {
                        RetVal = RetVal;
                    } else {
                        RetVal = 30.5;
                        letu_3.setText("30.5");
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Error:" + " is not valid");
                    letu_3.setText("30.5");

                }

//PUT VALUES OF BED2 INTO AN ARRAY
                double BED2Array_3[] = new double[101];
                for (int j = 0; j < 101; j++) {

                    double value1 = BED2_FINAL_3(j);
                    BED2Array_3[j] = value1;
                }

                //NEED TO MAKE A NEW SERIES EACH TIME THE FUNCTION IS CALLED!!! MAKE A IF STATEMENT FOR THIS        
                for (int i = 0; i < 101; i++) {
                    series9_3.getData().add(new XYChart.Data(i, BED2Array_3[i]));
                }
                series10_3.getData().add(new XYChart.Data(BED1_pc_3(), BED21_pc_3()));
                series11_3.getData().add(new XYChart.Data(BED1_pc_3(), BED22_pc_3()));

                series12_3.getData().add(new XYChart.Data(BED1_pc_3(), BED23_pc_3()));

                series13_3.getData().add(new XYChart.Data(BED1_pc_human_3(), BED2_FINAL_3(BED1_pc_human_3())));
                series14_3.getData().add(new XYChart.Data(0, BED2_FINAL_3(BED1_pc_human_3())));
                series14_3.getData().add(new XYChart.Data(BED1_pc_human_3(), BED2_FINAL_3(BED1_pc_human_3())));

                series15_3.getData().add(new XYChart.Data(BED1_pc_human_3(), 0));
                series15_3.getData().add(new XYChart.Data(BED1_pc_human_3(), BED2_FINAL_3(BED1_pc_human_3())));

                chart2_3.getData().addAll(series9_3, series10_3, series11_3, series12_3, series13_3, series14_3, series15_3);

                long endTime = System.nanoTime();
                long totalTime = endTime - startTime;
                System.out.println("Total time for calculation " + totalTime / 1e9 + " seconds");
            }

        });

        reset.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                out.setText("");
                BED1_text.setText("");
                BEDinit_text.setText("");
                BEDR_text1.setText("");
                BEDR2_TEXT.setText("");
                BED2_text.setText("");
                BEDret_text.setText("");
                Dret_text.setText("");
                p_high.setText("");
                p_low.setText("");
                warn_bed.setText("");

                s0.setValue(0.15);
                s1.setValue(0.1);
                BEDslider.setValue(35);
                NumOfYearsSlider.setValue(2);
                PercentageSlider.setValue(0);
                RiskOfMyel.setText("1");
                initalDose.setText("40");
                RetreatFrac.setText("20");
                NumFrac.setText("20");
                series9.getData().clear();
                series10.getData().clear();
                series11.getData().clear();
                series12.getData().clear();
                series12.getData().clear();
                series13.getData().clear();

                series14.getData().clear();
                series15.getData().clear();

            }
        });

        reset_2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                out_2.setText("");
                BED1_text_2.setText("");
                BEDinit_text_2.setText("");
                BEDR_text_2.setText("");
                BEDR2_TEXT_2.setText("");
                BED2_text_2.setText("");
                BEDret_text_2.setText("");
                Dret_text_2.setText("");
                p_high_2.setText("");
                p_low_2.setText("");
                warn_bed_2.setText("");
                ProDose_2.setText("");

                NumOfYearsSlider_2.setValue(2);
                PercentageSlider_2.setValue(0);
                RiskOfMyel_2.setText("1");
                initalDose_2.setText("40");
                NumFrac_2.setText("20");
                DHIGH_2.setText("1.6");
                letu_2.setText("30.5");
                letx_2.setText("5");
                RBE_CHECKBOX_2.setSelected(false);
                letx_2.setDisable(false);
                letx_text_2.setOpacity(1);
                letx_2.setOpacity(1);
                letu_2.setDisable(false);
                letu_2.setOpacity(1);
                letu_text_2.setOpacity(1);
                series9_2.getData().clear();

                series10_2.getData().clear();
                series11_2.getData().clear();
                series12_2.getData().clear();
                series12_2.getData().clear();
                series13_2.getData().clear();

                series14_2.getData().clear();
                series15_2.getData().clear();

            }
        });

        reset_3.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                out_3.setText("");
                BED1_text_3.setText("");
                BEDinit_text_3.setText("");
                BEDR_text_3.setText("");
                BEDR2_TEXT_3.setText("");
                BED2_text_3.setText("");
                BEDret_text_3.setText("");
                Dret_text_3.setText("");
                p_high_3.setText("");
                p_low_3.setText("");
                warn_bed_3.setText("");
                RBE_TEXT_3.setText("");

                NumOfYearsSlider_3.setValue(2);
                PercentageSlider_3.setValue(0);
                RiskOfMyel_3.setText("1");
                initalDose_3.setText("1.3");
                NumFrac_3.setText("30");
                letu_3.setText("30.5");
                letx_3.setText("3");
                RBE_CHECKBOX_3.setSelected(false);
                letx_3.setDisable(false);
                letx_text_3.setOpacity(1);
                letx_3.setOpacity(1);
                letu_3.setDisable(false);
                letu_3.setOpacity(1);
                letu_text_3.setOpacity(1);
                series9_3.getData().clear();

                series10_3.getData().clear();
                series11_3.getData().clear();
                series12_3.getData().clear();
                series12_3.getData().clear();
                series13_3.getData().clear();

                series14_3.getData().clear();
                series15_3.getData().clear();

            }
        });

        reset_4.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                out_4.setText("");
                BED1_text_4.setText("");
                BEDinit_text_4.setText("");
                BEDR_text_4.setText("");
                BEDR2_TEXT_4.setText("");
                BED2_text_4.setText("");
                BEDret_text_4.setText("");
                Dret_text_4.setText("");
                p_high_4.setText("");
                p_low_4.setText("");
                warn_bed_4.setText("");
                ProDose_4.setText("");

                NumOfYearsSlider_4.setValue(2);
                PercentageSlider_4.setValue(0);
                RiskOfMyel_4.setText("1");
                initalDose_4.setText("1.3");
                NumFrac_4.setText("30");
                DHIGH_4.setText("1.3");
                letu_4.setText("30.5");
                letx_4.setText("3");
                RBE_CHECKBOX_4.setSelected(false);
                letx_4.setDisable(false);
                letx_text_4.setOpacity(1);
                letx_4.setOpacity(1);
                letu_4.setDisable(false);
                letu_4.setOpacity(1);
                letu_text_4.setOpacity(1);
                series9_4.getData().clear();

                series10_4.getData().clear();
                series11_4.getData().clear();
                series12_4.getData().clear();
                series12_4.getData().clear();
                series13_4.getData().clear();

                series14_4.getData().clear();
                series15_4.getData().clear();

            }
        });
    }

    //CODE FOE THE RODENT DATA BUTTONS FOR EACH GRAPH - TAB1
    @FXML
    private void handleRdntBtn1Action(final ActionEvent event) {
        chart1.isVisible();
        if (chart1.isVisible() == false) {
            chart1.setVisible(true);
            chart2.setOpacity(0.4);
            chart2.getXAxis().setOpacity(0);
            chart2.getYAxis().setOpacity(0);
        } else {
            chart1.setVisible(false);
            chart2.setOpacity(1);
            chart2.getXAxis().setOpacity(1);
            chart2.getYAxis().setOpacity(1);
        }
    }

    //RODENT BUTTON TAB4
    @FXML
    private void handleRdntBtn4Action(final ActionEvent event) {

        chart1_4.isVisible();
        if (chart1_4.isVisible() == false) {
            chart1_4.setVisible(true);
            chart2_4.setOpacity(0.4);
            chart2_4.getXAxis().setOpacity(0);
            chart2_4.getYAxis().setOpacity(0);
        } else {
            chart1_4.setVisible(false);
            chart2_4.setOpacity(1);
            chart2_4.getXAxis().setOpacity(1);
            chart2_4.getYAxis().setOpacity(1);
        }
    }

    //RODENT BUTTON TAB4
    @FXML
    private void handleRdntBtn2Action(final ActionEvent event) {

        chart1_2.isVisible();
        if (chart1_2.isVisible() == false) {
            chart1_2.setVisible(true);
            chart2_2.setOpacity(0.4);
            chart2_2.getXAxis().setOpacity(0);
            chart2_2.getYAxis().setOpacity(0);
        } else {
            chart1_2.setVisible(false);
            chart2_2.setOpacity(1);
            chart2_2.getXAxis().setOpacity(1);
            chart2_2.getYAxis().setOpacity(1);
        }
    }
    //RODENT BUTTON TAB3

    @FXML
    private void handleRdntBtn3Action(final ActionEvent event) {

        chart1_3.isVisible();
        if (chart1_3.isVisible() == false) {
            chart1_3.setVisible(true);
            chart2_3.setOpacity(0.4);
            chart2_3.getXAxis().setOpacity(0);
            chart2_3.getYAxis().setOpacity(0);
        } else {
            chart1_3.setVisible(false);
            chart2_3.setOpacity(1);
            chart2_3.getXAxis().setOpacity(1);
            chart2_3.getYAxis().setOpacity(1);
        }
    }

//static varibles to be used for proton RBE Calculations
    public static double alpha_low = 0.06;
    public static double beta_low = 0.03;

    /////////////APPROXIMATED ERROR FCN ////////////////////////////////////////////////////////////////////
    public static double erf(double z) {
        double t = (double) (1.0 / (1.0 + 0.5 * Math.abs(z)));

        // use Horner's method
        double ans = (double) (1 - t * Math.exp(-z * z - 1.26551223
                + t * (1.00002368
                + t * (0.37409196
                + t * (0.09678418
                + t * (-0.18628806
                + t * (0.27886807
                + t * (-1.13520398
                + t * (1.48851587
                + t * (-0.82215223
                + t * (0.17087277)))))))))));
        if (z >= 0) {
            return ans;
        } else {
            return -ans;
        }

    }

}
