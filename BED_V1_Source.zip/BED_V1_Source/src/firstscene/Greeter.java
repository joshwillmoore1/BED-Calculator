/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author moore
 */
package firstscene;
public class Greeter{
    //Lambdas enables functional programming
    public void greet(Greeting greeting){
        greeting.perform();
    }
    
    public static void man(String[] args){
        Greeter greeter = new Greeter();
        HelloWorldGreeting helloworldGreeting = new HelloWorldGreeting();
        greeter.greet(helloworldGreeting);
    }
    
}
